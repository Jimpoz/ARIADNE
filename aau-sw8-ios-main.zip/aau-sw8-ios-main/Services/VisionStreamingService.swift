//
//  VisionStreamingService.swift
//  aau-sw8-ios
//

import AVFoundation
import Combine
import CoreImage
import Foundation
import UIKit

struct VisionResolvedLocation: Equatable {
    let kind: String
    let id: String
    let name: String
    let confidence: Double
    let spaceId: String?
    let buildingId: String?
    let buildingName: String?
    let campusId: String?
    let floorId: String?
    let floorIndex: Int?
    let centroidLat: Double?
    let centroidLng: Double?
}

final class VisionStreamingService: NSObject, ObservableObject {
    @Published var isConnected = false
    @Published var detections: [DetectionBox] = []
    /// Best-guess current location name resolved by the ml-vision server.
    @Published var resolvedLocationName: String = ""
    @Published var resolvedLocation: VisionResolvedLocation?

    private var webSocketTask: URLSessionWebSocketTask?
    private var urlSession: URLSession?
    private let frameQueue = DispatchQueue(label: "ariadne.vision.frames", qos: .userInitiated)
    private let ciContext = CIContext()
    private var lastFrameSentAt: Date = .distantPast
    // Cap at 15 fps — keeps bandwidth and server load reasonable
    private let minFrameInterval: TimeInterval = 1.0 / 15.0


    func connect(baseURL: String, facilityId: String, apiKey: String) {
        guard webSocketTask == nil else { return }
        let wsBase = Self.toWebSocketURL(baseURL)
        let encodedFacility = facilityId
            .addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? facilityId
        guard let url = URL(string: "\(wsBase)/api/v1/ml-vision/ws/stream/\(encodedFacility)") else {
            return
        }

        var request = URLRequest(url: url)
        request.setValue(apiKey, forHTTPHeaderField: "X-Api-Key")
        request.attachBearer()

        let config = URLSessionConfiguration.default
        urlSession = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        webSocketTask = urlSession?.webSocketTask(with: request)
        webSocketTask?.resume()
        receiveNext()
    }

    private static func toWebSocketURL(_ base: String) -> String {
        if base.hasPrefix("https://") {
            return "wss://" + base.dropFirst("https://".count)
        }
        if base.hasPrefix("http://") {
            return "ws://" + base.dropFirst("http://".count)
        }
        return base
    }

    func disconnect() {
        webSocketTask?.cancel(with: .goingAway, reason: nil)
        webSocketTask = nil
        urlSession = nil
        DispatchQueue.main.async {
            self.isConnected = false
            self.detections = []
            self.resolvedLocationName = ""
            self.resolvedLocation = nil
        }
    }

    func sendFrame(_ sampleBuffer: CMSampleBuffer) {
        guard isConnected, let task = webSocketTask else { return }
        let now = Date()
        guard now.timeIntervalSince(lastFrameSentAt) >= minFrameInterval else { return }
        lastFrameSentAt = now

        frameQueue.async { [weak self] in
            guard let self, let data = self.encodeFrame(sampleBuffer) else { return }
            task.send(.data(data)) { [weak self] error in
                if let error {
                    print("[VisionStream] send error: \(error)")
                    DispatchQueue.main.async { self?.isConnected = false }
                }
            }
        }
    }

    private func encodeFrame(_ sampleBuffer: CMSampleBuffer) -> Data? {
        guard let imageBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return nil }
        // .right rotation produces an upright portrait image for the server
        let ciImage = CIImage(cvPixelBuffer: imageBuffer).oriented(.right)
        guard let cgImage = ciContext.createCGImage(ciImage, from: ciImage.extent) else { return nil }
        return UIImage(cgImage: cgImage).jpegData(compressionQuality: 0.6)
    }

    private func receiveNext() {
        webSocketTask?.receive { [weak self] result in
            guard let self else { return }
            switch result {
            case .success(let message):
                let text: String? = {
                    switch message {
                    case .string(let s): return s
                    case .data(let d): return String(data: d, encoding: .utf8)
                    @unknown default: return nil
                    }
                }()
                if let text { self.parseFrame(text) }
                self.receiveNext()
            case .failure(let error):
                print("[VisionStream] receive error: \(error)")
                DispatchQueue.main.async { self.isConnected = false }
            }
        }
    }

    private func parseFrame(_ json: String) {
        guard let data = json.data(using: .utf8),
              let frame = try? JSONDecoder().decode(StreamFrame.self, from: data) else { return }

        let boxes = frame.detections.map {
            DetectionBox(
                rect: CGRect(x: $0.x, y: $0.y, width: $0.width, height: $0.height),
                label: $0.label,
                confidence: $0.confidence,
                isLandmarkMatch: $0.is_landmark_match ?? false,
                landmarkName: $0.landmark_name
            )
        }
        let resolved: VisionResolvedLocation? = frame.location.flatMap { remote in
            guard remote.kind.lowercased() != "unknown" else { return nil }
            return VisionResolvedLocation(
                kind: remote.kind,
                id: remote.id,
                name: remote.name,
                confidence: remote.confidence,
                spaceId: remote.space_id,
                buildingId: remote.building_id,
                buildingName: remote.building_name,
                campusId: remote.campus_id,
                floorId: remote.floor_id,
                floorIndex: remote.floor_index,
                centroidLat: remote.centroid_lat,
                centroidLng: remote.centroid_lng
            )
        }
        DispatchQueue.main.async {
            self.detections = boxes
            self.resolvedLocationName = frame.location?.name ?? ""
            if self.resolvedLocation?.id != resolved?.id {
                self.resolvedLocation = resolved
            }
        }
    }
}

extension VisionStreamingService: URLSessionWebSocketDelegate {
    func urlSession(_ session: URLSession,
                    webSocketTask: URLSessionWebSocketTask,
                    didOpenWithProtocol protocol: String?) {
        DispatchQueue.main.async { self.isConnected = true }
    }

    func urlSession(_ session: URLSession,
                    webSocketTask: URLSessionWebSocketTask,
                    didCloseWith closeCode: URLSessionWebSocketTask.CloseCode,
                    reason: Data?) {
        DispatchQueue.main.async { self.isConnected = false }
    }
}

// MARK: - Decodable models matching serving/main.py StreamFrame

private struct StreamFrame: Decodable {
    let detections: [RemoteDetection]
    let location: RemoteLocation?
}

private struct RemoteDetection: Decodable {
    let label: String
    let confidence: Float
    let x: CGFloat
    let y: CGFloat
    let width: CGFloat
    let height: CGFloat
    let is_landmark_match: Bool?
    let landmark_name: String?
}

private struct RemoteLocation: Decodable {
    let kind: String
    let id: String
    let name: String
    let confidence: Double
    let space_id: String?
    let building_id: String?
    let building_name: String?
    let campus_id: String?
    let floor_id: String?
    let floor_index: Int?
    let centroid_lat: Double?
    let centroid_lng: Double?
}
