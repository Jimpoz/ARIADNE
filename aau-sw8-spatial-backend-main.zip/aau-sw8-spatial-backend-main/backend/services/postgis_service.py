"""
Schema:
  organizations   (entity that owns campuses, e.g. a university/corporation)
  campuses        (belongs to an organization)
  buildings       (belongs to a campus + organization)
  building_spaces (base)
    ├── rooms
    ├── amenities
    ├── corridors
    ├── stairs
    ├── elevators
    ├── doors
    ├── connectors
    ├── outdoor_spaces
    └── other_spaces
  floors          (floor plans + bounds)
  imports         (raw import JSON payloads)

Auth & tenancy:
  app_users            (login identities, bcrypt password_hash)
  organization_members (which user has which role in which org)
  audit_log            (append-only record of auth + privileged actions)
"""

from sqlalchemy import (
    create_engine, Column, String, Float, Integer, DateTime, Boolean, ForeignKey, Enum as SQLEnum,
    Text, or_, text,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.dialects.postgresql import JSONB
from geoalchemy2 import Geometry
from geoalchemy2.shape import to_shape
from pgvector.sqlalchemy import Vector
from datetime import datetime
from urllib.parse import urlparse, urlunparse, quote
import json
import enum
from core.config import settings
from core.request_context import current_is_service, current_org_id
from shapely.geometry import Polygon

Base = declarative_base()


class EntityType(enum.Enum):
    """Organization entity types."""
    UNIVERSITY = "UNIVERSITY"
    CORPORATION = "CORPORATION"
    PUBLIC_HEALTH = "PUBLIC_HEALTH"
    HOSPITAL = "HOSPITAL"
    GOVERNMENT = "GOVERNMENT"
    OTHER = "OTHER"


class OrgRole(enum.Enum):
    """Role a user holds inside an organization."""
    OWNER = "owner"
    EDITOR = "editor"
    VIEWER = "viewer"


def _safe_db_url(raw_url: str) -> str:
    try:
        parsed = urlparse(raw_url)
        if parsed.username is None or parsed.password is None:
            return raw_url
        userinfo = f"{quote(parsed.username, safe='%')}:{quote(parsed.password, safe='%')}"
        netloc = f"{userinfo}@{parsed.hostname}"
        if parsed.port:
            netloc += f":{parsed.port}"
        return urlunparse((
            parsed.scheme, netloc, parsed.path,
            parsed.params, parsed.query, parsed.fragment,
        ))
    except Exception as exc:
        print(f"[PostGISService] Could not encode DB URL: {exc}")
        return raw_url


# --- Organization & Campus Models ---

class Organization(Base):
    """Organization/entity that owns one or more campuses."""
    __tablename__ = "organizations"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    entity_type = Column(SQLEnum(EntityType), default=EntityType.OTHER)
    description = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class AppUser(Base):
    """Login identity. Password is stored as a bcrypt hash."""
    __tablename__ = "app_users"

    id = Column(String, primary_key=True)
    email = Column(String, nullable=False, unique=True, index=True)
    password_hash = Column(String, nullable=False)
    full_name = Column(String)
    is_active = Column(Boolean, default=True, nullable=False)
    mfa_enabled = Column(Boolean, default=False, nullable=False)
    mfa_method = Column(String, default="totp", nullable=False)
    mfa_secret = Column(String)
    mfa_recovery_codes = Column(JSONB)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class OrganizationMember(Base):
    """Mapping table: which user has which role in which organization.

    A user can belong to multiple organizations, with a different role in each."""
    __tablename__ = "organization_members"

    user_id = Column(
        String, ForeignKey("app_users.id", ondelete="CASCADE"),
        primary_key=True,
    )
    organization_id = Column(
        String, ForeignKey("organizations.id", ondelete="CASCADE"),
        primary_key=True,
    )
    role = Column(SQLEnum(OrgRole), nullable=False, default=OrgRole.VIEWER)
    created_at = Column(DateTime, default=datetime.utcnow)


class PasswordResetToken(Base):
    """One-time token for the forgot-password / reset flow."""
    __tablename__ = "password_reset_tokens"

    id = Column(String, primary_key=True)
    user_id = Column(
        String, ForeignKey("app_users.id", ondelete="CASCADE"),
        nullable=False, index=True,
    )
    token_hash = Column(String, nullable=False)
    expires_at = Column(DateTime, nullable=False, index=True)
    used_at = Column(DateTime)
    ip_address = Column(String)
    user_agent = Column(String)
    created_at = Column(DateTime, default=datetime.utcnow)


class AuditLog(Base):
    """Append-only record of auth + privileged actions. Never updated, never
    deleted. `subject_user_id` may be NULL for failed login attempts where the
    email did not resolve to a known user."""
    __tablename__ = "audit_log"

    id = Column(String, primary_key=True)
    subject_user_id = Column(String, ForeignKey("app_users.id", ondelete="SET NULL"), index=True)
    subject_email = Column(String, index=True)
    organization_id = Column(String, ForeignKey("organizations.id", ondelete="SET NULL"), index=True)
    action = Column(String, nullable=False, index=True)
    success = Column(Boolean, nullable=False, default=True)
    ip_address = Column(String)
    user_agent = Column(String)
    detail = Column(JSONB)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)


class Campus(Base):
    """Campus that belongs to an organization."""
    __tablename__ = "campuses"

    id = Column(String, primary_key=True)
    organization_id = Column(
        String, ForeignKey("organizations.id"), nullable=True, index=True,
    )
    name = Column(String, nullable=False)
    description = Column(String)
    is_public = Column(Boolean, default=False, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Building(Base):
    """Building that belongs to a campus. ``is_public`` is denormalized
    from the parent campus so RLS policies don't need a subselect on every
    read; ``CampusRepository.set_public`` keeps the children in sync."""
    __tablename__ = "buildings"

    id = Column(String, primary_key=True)
    campus_id = Column(String, ForeignKey("campuses.id"), nullable=False, index=True)
    organization_id = Column(
        String, ForeignKey("organizations.id"), nullable=True, index=True,
    )
    name = Column(String, nullable=False)
    short_name = Column(String)
    address = Column(String)
    origin_lat = Column(Float)
    origin_lng = Column(Float)
    origin_bearing = Column(Float, default=0.0)
    floor_count = Column(Integer)
    is_public = Column(Boolean, default=False, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# --- Categories ---
_ROOM_TYPES = {
    "ROOM_GENERIC", "ROOM_OFFICE", "ROOM_CLASSROOM", "ROOM_LECTURE_HALL",
    "ROOM_LAB", "ROOM_MEETING", "ROOM_STORAGE", "ROOM_UTILITY",
    "RESTROOM", "RESTROOM_ACCESSIBLE",
}
_AMENITY_TYPES = {"CAFETERIA", "CAFE", "LIBRARY", "GYM", "AUDITORIUM", "SHOP"}
_CORRIDOR_TYPES = {
    "CORRIDOR", "CORRIDOR_SEGMENT", "LOBBY", "WAITING_AREA", "RECEPTION",
    "ENTRANCE", "ENTRANCE_SECONDARY", "EXIT_EMERGENCY",
}
_STAIRS_TYPES = {"STAIRCASE", "ESCALATOR", "OUTDOOR_STAIRS", "RAMP"}
_ELEVATOR_TYPES = {"ELEVATOR"}
_DOOR_TYPES = {
    "DOOR_STANDARD", "DOOR_AUTOMATIC", "DOOR_LOCKED", "DOOR_EMERGENCY",
    "PASSAGE", "OPEN",
}
_CONNECTOR_TYPES = {"BRIDGE", "TUNNEL", "COVERED_WALKWAY"}
_OUTDOOR_TYPES = {"OUTDOOR_PATH", "OUTDOOR_PLAZA", "OUTDOOR_COURTYARD", "PARKING"}


def _category_for(space_type: str | None) -> str:
    if not space_type:
        return "other"
    s = space_type.upper()
    if s in _ROOM_TYPES:
        return "room"
    if s in _AMENITY_TYPES:
        return "amenity"
    if s in _CORRIDOR_TYPES:
        return "corridor"
    if s in _STAIRS_TYPES:
        return "stairs"
    if s in _ELEVATOR_TYPES:
        return "elevator"
    if s in _DOOR_TYPES:
        return "door"
    if s in _CONNECTOR_TYPES:
        return "connector"
    if s in _OUTDOOR_TYPES:
        return "outdoor"
    return "other"


# --- Models ---

class BuildingSpace(Base):
    """Base table for every space."""
    __tablename__ = "building_spaces"

    id = Column(String, primary_key=True)
    space_category = Column(String, index=True, nullable=False)
    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    campus_id = Column(String, index=True)
    building_id = Column(String, index=True)
    floor_id = Column(String, index=True)
    display_name = Column(String)
    space_type = Column(String, index=True)
    floor_index = Column(Integer)
    centroid_x = Column(Float)
    centroid_y = Column(Float)
    centroid_lat = Column(Float)
    centroid_lng = Column(Float)
    width_m = Column(Float)
    length_m = Column(Float)
    area_m2 = Column(Float)
    geometry = Column(Geometry("POLYGON", srid=0))
    geometry_global = Column(Geometry("POLYGON", srid=4326))
    is_accessible = Column(Boolean, default=True)
    is_navigable = Column(Boolean, default=True)
    is_outdoor = Column(Boolean, default=False)
    capacity = Column(Integer)
    tags = Column(String)
    meta_data = Column(String)
    # 384-d sentence-transformer ("all-MiniLM-L6-v2") embedding of
    # "{display_name}. Type: {space_type}. Tags: {tags}". Powers the
    # assistant's vector search via the pgvector HNSW index
    # (see _ensure_vector_index below). Written by sync_space; never
    # mutated client-side.
    embedding = Column(Vector(384), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __mapper_args__ = {
        "polymorphic_on": space_category,
        "polymorphic_identity": "space",
    }


def _subclass(table_name: str, identity: str):
    """Factory for joined-inheritance subclasses with zero extra columns.
    Allows queries like `session.query(Room).all()` to hit only that table."""
    return type(
        identity.capitalize(),
        (BuildingSpace,),
        {
            "__tablename__": table_name,
            "id": Column(
                String, ForeignKey("building_spaces.id", ondelete="CASCADE"),
                primary_key=True,
            ),
            "__mapper_args__": {"polymorphic_identity": identity},
        },
    )


Room = _subclass("rooms", "room")
Amenity = _subclass("amenities", "amenity")
Corridor = _subclass("corridors", "corridor")
Stairs = _subclass("stairs", "stairs")
Elevator = _subclass("elevators", "elevator")
Door = _subclass("doors", "door")
Connector = _subclass("connectors", "connector")
OutdoorSpace = _subclass("outdoor_spaces", "outdoor")
OtherSpace = _subclass("other_spaces", "other")

_MODEL_BY_CATEGORY = {
    "room": Room,
    "amenity": Amenity,
    "corridor": Corridor,
    "stairs": Stairs,
    "elevator": Elevator,
    "door": Door,
    "connector": Connector,
    "outdoor": OutdoorSpace,
    "other": OtherSpace,
}


class Floor(Base):
    """Floor plan metadata + bounding polygon. ``is_public`` is denormalized
    from the parent campus, kept in sync by ``CampusRepository.set_public``."""
    __tablename__ = "floors"

    id = Column(String, primary_key=True)
    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    campus_id = Column(String, index=True)
    building_id = Column(String, index=True)
    floor_id = Column(String, index=True)
    floor_index = Column(Integer, index=True)
    display_name = Column(String)
    floor_plan_url = Column(String)
    floor_plan_scale = Column(Float)
    floor_plan_origin_x = Column(Float)
    floor_plan_origin_y = Column(Float)
    bounds_geometry = Column(Geometry("POLYGON", srid=0))
    is_public = Column(Boolean, default=False, nullable=False, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ImportRecord(Base):
    """Raw JSON payload from /import endpoint, one row per campus.
    Class is named ImportRecord (not Import) because `import` is a Python
    keyword; the table itself is called `imports`."""
    __tablename__ = "imports"

    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    campus_id = Column(String, primary_key=True)
    schema_version = Column(String)
    payload = Column(JSONB)
    imported_at = Column(
        DateTime, default=datetime.utcnow, onupdate=datetime.utcnow,
    )


class SpaceConnection(Base):
    """Directed mapmaker-created edge between two spaces via a door/passage."""

    __tablename__ = "space_connections"

    id = Column(String, primary_key=True)
    connection_group_id = Column(String, index=True)
    from_space_id = Column(String, index=True, nullable=False)
    to_space_id = Column(String, index=True, nullable=False)
    door_space_id = Column(String, index=True)
    connection_type = Column(String)
    is_accessible = Column(Boolean, default=True)
    door_cx = Column(Float)
    door_cy = Column(Float)
    created_at = Column(DateTime, default=datetime.utcnow)


class Landmark(Base):
    """User-registered visual landmark anchored to a Space."""

    __tablename__ = "landmarks"

    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    space_id = Column(String, index=True, nullable=False)
    floor_id = Column(String, index=True)
    building_id = Column(String, index=True)
    campus_id = Column(String, index=True)
    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    image_b64 = Column(Text)
    image_width = Column(Integer)
    image_height = Column(Integer)
    centroid_x = Column(Float)
    centroid_y = Column(Float)
    centroid_lat = Column(Float)
    centroid_lng = Column(Float)
    created_by = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class WifiFingerprint(Base):
    """A Wi-Fi RSSI (+ optional RTT) fingerprint sample captured while
    standing in a Space. Used for indoor positioning via kNN. PostGIS-only
    (not mirrored to Neo4j) — it's bulk numeric data, not a graph entity."""

    __tablename__ = "wifi_fingerprints"

    id = Column(String, primary_key=True)
    space_id = Column(String, index=True, nullable=False)
    floor_id = Column(String, index=True)
    building_id = Column(String, index=True)
    campus_id = Column(String, index=True)
    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    # bssid -> rssi in dBm (negative ints).
    readings = Column(JSONB, nullable=False)
    # bssid -> distance in mm from 802.11mc FTM ranging, when available.
    rtt_distances_mm = Column(JSONB)
    sample_count = Column(Integer, default=1)
    created_by = Column(String, index=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class WifiAccessPoint(Base):
    """A known Wi-Fi access point. Its on-floor position (x,y) is reserved
    for RTT trilateration and stays null until surveyed; supports_rtt flags
    whether the AP answers 802.11mc FTM ranging."""

    __tablename__ = "wifi_access_points"

    bssid = Column(String, primary_key=True)
    ssid = Column(String)
    floor_id = Column(String, index=True)
    building_id = Column(String, index=True)
    campus_id = Column(String, index=True)
    organization_id = Column(String, ForeignKey("organizations.id"), index=True)
    x = Column(Float)
    y = Column(Float)
    supports_rtt = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class UserDailyActivity(Base):
    """Per-user, per-day walking totals. Keyed by the client's local date
    (``day_date`` as YYYY-MM-DD) so the daily reset happens at the user's
    local midnight with no scheduled job: a new day simply has no row yet and
    reads as zero."""

    __tablename__ = "user_daily_activity"

    user_id = Column(String, ForeignKey("app_users.id", ondelete="CASCADE"), primary_key=True)
    day_date = Column(String, primary_key=True)
    distance_m = Column(Float, default=0.0, nullable=False)
    steps = Column(Integer, default=0, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


# --- Service ---
_shared_engine = None
_shared_session_local = None
_schema_initialized = False


class PostGISService:
    """Handles synchronization of building data to PostGIS."""

    def __init__(self):
        global _shared_engine, _shared_session_local, _schema_initialized

        if not settings.supabase_enable_sync or not settings.supabase_db_url:
            self.engine = None
            self.SessionLocal = None
            return

        if _shared_engine is None:
            _shared_engine = create_engine(
                _safe_db_url(settings.supabase_db_url),
                echo=False,
                pool_size=2,
                max_overflow=5,
                pool_pre_ping=True,
                pool_recycle=300,
            )
            _shared_session_local = sessionmaker(
                autocommit=False, autoflush=False, bind=_shared_engine,
            )

        self.engine = _shared_engine
        self.SessionLocal = _shared_session_local

        if not _schema_initialized:
            self._init_db()
            _schema_initialized = True

    def _init_db(self):
        if self.engine:
            self._ensure_extensions()
            Base.metadata.create_all(bind=self.engine)
            self._ensure_columns()
            self._ensure_vector_index()

    def _ensure_extensions(self) -> None:
        try:
            with self.engine.begin() as conn:
                conn.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        except Exception as exc:
            print(f"[PostGISService] _ensure_extensions failed: {exc}")

    _ADDED_COLUMNS = (
        ("campuses", "is_public", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("buildings", "is_public", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("floors", "is_public", "BOOLEAN NOT NULL DEFAULT FALSE"),
        ("app_users", "mfa_method", "VARCHAR NOT NULL DEFAULT 'totp'"),
        ("space_connections", "door_cx", "DOUBLE PRECISION"),
        ("space_connections", "door_cy", "DOUBLE PRECISION"),
        ("building_spaces", "embedding", "vector(384)"),
        ("landmarks", "image_b64", "TEXT"),
        ("landmarks", "image_width", "INTEGER"),
        ("landmarks", "image_height", "INTEGER"),
        ("landmarks", "created_by", "VARCHAR"),
        ("landmarks", "floor_id", "VARCHAR"),
        ("landmarks", "building_id", "VARCHAR"),
        ("landmarks", "campus_id", "VARCHAR"),
        ("landmarks", "organization_id", "VARCHAR"),
    )

    def _ensure_columns(self) -> None:
        try:
            with self.engine.begin() as conn:
                for table, col, ddl in self._ADDED_COLUMNS:
                    conn.execute(text(
                        f'ALTER TABLE "{table}" ADD COLUMN IF NOT EXISTS "{col}" {ddl}'
                    ))
        except Exception as exc:
            print(f"[PostGISService] _ensure_columns failed: {exc}")

    def _ensure_vector_index(self) -> None:
        """HNSW index with cosine ops for the assistant's RAG retrieval.
        IF NOT EXISTS makes this idempotent across cold starts."""
        try:
            with self.engine.begin() as conn:
                conn.execute(text(
                    "CREATE INDEX IF NOT EXISTS space_embedding_idx "
                    "ON building_spaces USING hnsw "
                    "(embedding vector_cosine_ops)"
                ))
        except Exception as exc:
            print(f"[PostGISService] _ensure_vector_index failed: {exc}")

    # --- row-level security ---
    _RLS_PUBLIC_READ_TABLES = ("campuses", "buildings", "floors")
    _RLS_TABLES = (
        "campuses", "buildings", "floors", "imports", "landmarks",
        "wifi_fingerprints", "wifi_access_points",
    )

    def apply_rls_policies(self) -> bool:
        """Enable RLS + install per-tenant policies on org-scoped tables."""
        if not self.engine:
            return False
        try:
            with self.engine.begin() as conn:
                for table in self._RLS_TABLES:
                    public_read = table in self._RLS_PUBLIC_READ_TABLES
                    using_clause = (
                        "current_setting('app.is_service', true) = 'true' "
                        "OR organization_id = current_setting('app.org_id', true)"
                    )
                    if public_read:
                        using_clause += " OR is_public = true"
                    conn.execute(text(f'ALTER TABLE "{table}" ENABLE ROW LEVEL SECURITY'))
                    conn.execute(text(f'DROP POLICY IF EXISTS org_isolation ON "{table}"'))
                    conn.execute(text(
                        f'''
                        CREATE POLICY org_isolation ON "{table}"
                            USING ({using_clause})
                            WITH CHECK (
                                current_setting('app.is_service', true) = 'true'
                                OR organization_id = current_setting('app.org_id', true)
                            )
                        '''
                    ))
            return True
        except Exception as exc:
            print(f"[PostGISService] apply_rls_policies failed: {exc}")
            return False

    def _open_session(self):
        if not self.SessionLocal:
            return None
        session = self.SessionLocal()
        if not settings.auth_rls_enabled:
            return session
        org_id = current_org_id.get()
        is_service = current_is_service.get()
        if is_service:
            session.execute(text("SET LOCAL app.is_service = 'true'"))
        if org_id:
            session.execute(text("SET LOCAL app.org_id = :org_id"), {"org_id": org_id})
        return session


    def insert_wifi_fingerprint(
        self,
        *,
        fp_id: str,
        space_id: str,
        floor_id: str | None,
        building_id: str | None,
        campus_id: str | None,
        organization_id: str | None,
        readings: dict,
        rtt_distances_mm: dict | None = None,
        sample_count: int = 1,
        created_by: str | None = None,
    ) -> bool:
        session = self._open_session()
        if session is None:
            return False
        try:
            session.add(WifiFingerprint(
                id=fp_id,
                space_id=space_id,
                floor_id=floor_id,
                building_id=building_id,
                campus_id=campus_id,
                organization_id=organization_id,
                readings=readings,
                rtt_distances_mm=rtt_distances_mm,
                sample_count=sample_count or 1,
                created_by=created_by,
            ))
            session.commit()
            return True
        finally:
            session.close()

    def wifi_fingerprints_for_floor(self, floor_id: str) -> list[dict]:
        """All fingerprints on a floor (RLS-scoped to the caller's org)."""
        session = self._open_session()
        if session is None:
            return []
        try:
            rows = session.query(WifiFingerprint).filter(
                WifiFingerprint.floor_id == floor_id
            ).all()
            return [
                {
                    "space_id": r.space_id,
                    "readings": r.readings or {},
                    "rtt_distances_mm": r.rtt_distances_mm or {},
                }
                for r in rows
            ]
        finally:
            session.close()

    def wifi_fingerprint_counts_for_floor(self, floor_id: str) -> dict:
        """space_id -> number of stored fingerprints (for survey progress)."""
        session = self._open_session()
        if session is None:
            return {}
        try:
            rows = session.query(WifiFingerprint.space_id).filter(
                WifiFingerprint.floor_id == floor_id
            ).all()
            counts: dict = {}
            for (space_id,) in rows:
                counts[space_id] = counts.get(space_id, 0) + 1
            return counts
        finally:
            session.close()

    def upsert_wifi_access_point(
        self,
        *,
        bssid: str,
        ssid: str | None,
        floor_id: str | None,
        building_id: str | None,
        campus_id: str | None,
        organization_id: str | None,
        x: float | None = None,
        y: float | None = None,
        supports_rtt: bool = False,
    ) -> bool:
        session = self._open_session()
        if session is None:
            return False
        try:
            rec = session.query(WifiAccessPoint).filter_by(bssid=bssid).first()
            if rec:
                rec.ssid = ssid if ssid is not None else rec.ssid
                rec.floor_id = floor_id or rec.floor_id
                rec.building_id = building_id or rec.building_id
                rec.campus_id = campus_id or rec.campus_id
                rec.organization_id = organization_id or rec.organization_id
                if x is not None:
                    rec.x = x
                if y is not None:
                    rec.y = y
                rec.supports_rtt = supports_rtt
                rec.updated_at = datetime.utcnow()
            else:
                session.add(WifiAccessPoint(
                    bssid=bssid,
                    ssid=ssid,
                    floor_id=floor_id,
                    building_id=building_id,
                    campus_id=campus_id,
                    organization_id=organization_id,
                    x=x,
                    y=y,
                    supports_rtt=supports_rtt,
                ))
            session.commit()
            return True
        finally:
            session.close()

    def wifi_access_points_for_floor(self, floor_id: str) -> list[dict]:
        session = self._open_session()
        if session is None:
            return []
        try:
            rows = session.query(WifiAccessPoint).filter(
                WifiAccessPoint.floor_id == floor_id
            ).all()
            return [
                {
                    "bssid": r.bssid,
                    "ssid": r.ssid,
                    "x": r.x,
                    "y": r.y,
                    "supports_rtt": bool(r.supports_rtt),
                }
                for r in rows
            ]
        finally:
            session.close()

    # --- daily activity (distance + steps) ---

    def get_daily_activity(self, user_id: str, day: str) -> dict:
        session = self._open_session()
        if session is None:
            return {"distance_m": 0.0, "steps": 0}
        try:
            rec = session.query(UserDailyActivity).filter_by(
                user_id=user_id, day_date=day
            ).first()
            if rec is None:
                return {"distance_m": 0.0, "steps": 0}
            return {"distance_m": float(rec.distance_m or 0.0), "steps": int(rec.steps or 0)}
        finally:
            session.close()

    def add_daily_activity(
        self, user_id: str, day: str, distance_m: float, steps: int
    ) -> dict:
        """Increment today's totals (upsert). Returns the new totals."""
        session = self._open_session()
        if session is None:
            return {"distance_m": 0.0, "steps": 0}
        try:
            rec = session.query(UserDailyActivity).filter_by(
                user_id=user_id, day_date=day
            ).first()
            if rec is None:
                rec = UserDailyActivity(
                    user_id=user_id,
                    day_date=day,
                    distance_m=max(0.0, distance_m),
                    steps=max(0, steps),
                )
                session.add(rec)
            else:
                rec.distance_m = float(rec.distance_m or 0.0) + max(0.0, distance_m)
                rec.steps = int(rec.steps or 0) + max(0, steps)
                rec.updated_at = datetime.utcnow()
            session.commit()
            return {"distance_m": float(rec.distance_m or 0.0), "steps": int(rec.steps or 0)}
        finally:
            session.close()

    # --- organizations ---

    def sync_organization(self, org_data: dict) -> bool:
        """Enqueue an upsert of the organization row (drained by the sync worker)."""
        from services.sync_outbox import enqueue
        return enqueue("sync_organization", {"org_data": org_data})

    def _apply_sync_organization(self, org_data: dict) -> None:
        session = self._open_session()
        record = session.query(Organization).filter_by(
            id=org_data["id"]
        ).first()

        entity_type = org_data.get("entity_type")
        if entity_type is not None and not isinstance(entity_type, EntityType):
            raw = entity_type.value if hasattr(entity_type, "value") else str(entity_type)
            try:
                entity_type = EntityType(raw)
            except ValueError:
                entity_type = EntityType.OTHER

        if record:
            record.name = org_data.get("name", record.name)
            if entity_type is not None:
                record.entity_type = entity_type
            record.description = org_data.get("description", record.description)
            record.updated_at = datetime.utcnow()
        else:
            record = Organization(
                id=org_data["id"],
                name=org_data.get("name", ""),
                entity_type=entity_type or EntityType.OTHER,
                description=org_data.get("description"),
            )
            session.add(record)
        session.commit()
        session.close()

    def delete_organization(self, organization_id: str) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("delete_organization", {"organization_id": organization_id})

    def _apply_delete_organization(self, organization_id: str) -> None:
        session = self._open_session()
        record = session.query(Organization).filter_by(id=organization_id).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    def delete_organization_cascade(
        self,
        organization_id: str,
        campus_ids: list[str],
        building_ids: list[str],
        floor_pks: list[str],
        space_ids: list[str],
    ) -> bool:
        """Cascade-delete an organization and every descendant row in PostGIS."""
        from services.sync_outbox import enqueue
        return enqueue("delete_organization_cascade", {
            "organization_id": organization_id,
            "campus_ids": list(campus_ids),
            "building_ids": list(building_ids),
            "floor_pks": list(floor_pks),
            "space_ids": list(space_ids),
        })

    def _apply_delete_organization_cascade(
        self,
        organization_id: str,
        campus_ids: list[str] | None = None,
        building_ids: list[str] | None = None,
        floor_pks: list[str] | None = None,
        space_ids: list[str] | None = None,
    ) -> None:
        session = self._open_session()
        try:
            current_space_ids = [
                row[0] for row in session.execute(
                    text(
                        "SELECT id FROM building_spaces "
                        "WHERE organization_id = :org_id"
                    ),
                    {"org_id": organization_id},
                )
            ]
            if current_space_ids:
                session.query(SpaceConnection).filter(
                    or_(
                        SpaceConnection.from_space_id.in_(current_space_ids),
                        SpaceConnection.to_space_id.in_(current_space_ids),
                        SpaceConnection.door_space_id.in_(current_space_ids),
                        SpaceConnection.connection_group_id.in_(current_space_ids),
                    )
                ).delete(synchronize_session=False)

            session.query(BuildingSpace).filter(
                BuildingSpace.organization_id == organization_id
            ).delete(synchronize_session=False)

            session.query(Floor).filter(
                Floor.organization_id == organization_id
            ).delete(synchronize_session=False)

            session.query(Building).filter(
                Building.organization_id == organization_id
            ).delete(synchronize_session=False)

            session.query(Campus).filter(
                Campus.organization_id == organization_id
            ).delete(synchronize_session=False)

            session.query(ImportRecord).filter(
                ImportRecord.organization_id == organization_id
            ).delete(synchronize_session=False)

            session.query(Organization).filter_by(id=organization_id).delete(
                synchronize_session=False
            )

            session.commit()
        finally:
            session.close()

    # --- campuses ---

    def sync_campus(self, campus_data: dict) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("sync_campus", {"campus_data": campus_data})

    def _apply_sync_campus(self, campus_data: dict) -> None:
        session = self._open_session()
        record = session.query(Campus).filter_by(id=campus_data["id"]).first()
        if record:
            record.organization_id = campus_data.get(
                "organization_id", record.organization_id
            )
            record.name = campus_data.get("name", record.name)
            record.description = campus_data.get("description", record.description)
            if "is_public" in campus_data:
                record.is_public = bool(campus_data["is_public"])
            record.updated_at = datetime.utcnow()
        else:
            record = Campus(
                id=campus_data["id"],
                organization_id=campus_data.get("organization_id"),
                name=campus_data.get("name", ""),
                description=campus_data.get("description"),
                is_public=bool(campus_data.get("is_public", False)),
            )
            session.add(record)
        session.commit()
        session.close()

    def delete_campus(self, campus_id: str) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("delete_campus", {"campus_id": campus_id})

    def _apply_delete_campus(self, campus_id: str) -> None:
        session = self._open_session()
        record = session.query(Campus).filter_by(id=campus_id).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    def delete_campus_cascade(
        self,
        campus_id: str,
        building_ids: list[str],
        floor_pks: list[str],
        space_ids: list[str],
    ) -> bool:
        """Cascade-delete a campus and every descendant row in PostGIS."""
        from services.sync_outbox import enqueue
        return enqueue("delete_campus_cascade", {
            "campus_id": campus_id,
            "building_ids": list(building_ids),
            "floor_pks": list(floor_pks),
            "space_ids": list(space_ids),
        })

    def _apply_delete_campus_cascade(
        self,
        campus_id: str,
        building_ids: list[str],
        floor_pks: list[str],
        space_ids: list[str],
    ) -> None:
        session = self._open_session()

        if space_ids:
            session.query(SpaceConnection).filter(
                or_(
                    SpaceConnection.from_space_id.in_(space_ids),
                    SpaceConnection.to_space_id.in_(space_ids),
                    SpaceConnection.door_space_id.in_(space_ids),
                    SpaceConnection.connection_group_id.in_(space_ids),
                )
            ).delete(synchronize_session=False)

            session.query(BuildingSpace).filter(
                BuildingSpace.id.in_(space_ids)
            ).delete(synchronize_session=False)

        if floor_pks:
            session.query(Floor).filter(
                Floor.id.in_(floor_pks)
            ).delete(synchronize_session=False)

        if building_ids:
            session.query(Building).filter(
                Building.id.in_(building_ids)
            ).delete(synchronize_session=False)

        session.query(Campus).filter_by(id=campus_id).delete(
            synchronize_session=False
        )

        session.commit()
        session.close()

    # --- buildings ---

    def sync_building(self, building_data: dict) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("sync_building", {"building_data": building_data})

    def _apply_sync_building(self, building_data: dict) -> None:
        session = self._open_session()
        record = session.query(Building).filter_by(id=building_data["id"]).first()
        fields = [
            "campus_id", "organization_id", "name", "short_name", "address",
            "origin_lat", "origin_lng", "origin_bearing", "floor_count",
            "is_public",
        ]
        if record:
            for f in fields:
                if f in building_data:
                    setattr(record, f, building_data[f])
            record.updated_at = datetime.utcnow()
        else:
            record = Building(
                id=building_data["id"],
                **{f: building_data.get(f) for f in fields if f in building_data},
            )
            session.add(record)
        session.commit()
        session.close()

    def delete_building(self, building_id: str) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("delete_building", {"building_id": building_id})

    def _apply_delete_building(self, building_id: str) -> None:
        session = self._open_session()
        record = session.query(Building).filter_by(id=building_id).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    def delete_building_cascade(
        self,
        building_id: str,
        space_ids: list[str],
        floor_ids: list[str],
    ) -> bool:
        """Cascade-delete a building and all its descendants in PostGIS.

        `space_ids` is the full set of Space node IDs from Neo4j (rooms,
        subspaces, and any door/passage node that used to connect to them).
        `floor_ids` are the bare Floor node IDs; the PostGIS floors table keys
        on `{building_id}_{floor_id}`.
        """
        from services.sync_outbox import enqueue
        return enqueue("delete_building_cascade", {
            "building_id": building_id,
            "space_ids": list(space_ids),
            "floor_ids": list(floor_ids),
        })

    def _apply_delete_building_cascade(
        self,
        building_id: str,
        space_ids: list[str],
        floor_ids: list[str],
    ) -> None:
        session = self._open_session()

        if space_ids:
            session.query(SpaceConnection).filter(
                or_(
                    SpaceConnection.from_space_id.in_(space_ids),
                    SpaceConnection.to_space_id.in_(space_ids),
                    SpaceConnection.door_space_id.in_(space_ids),
                    SpaceConnection.connection_group_id.in_(space_ids),
                )
            ).delete(synchronize_session=False)

            session.query(BuildingSpace).filter(
                BuildingSpace.id.in_(space_ids)
            ).delete(synchronize_session=False)

        if floor_ids:
            composed = [f"{building_id}_{fid}" for fid in floor_ids]
            session.query(Floor).filter(
                Floor.id.in_(composed)
            ).delete(synchronize_session=False)

        session.query(Building).filter_by(id=building_id).delete(
            synchronize_session=False
        )

        session.commit()
        session.close()

    # --- spaces ---

    def sync_space(self, space_data: dict) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("sync_space", {"space_data": space_data})

    def _apply_sync_space(self, space_data: dict) -> None:
        session = self._open_session()
        category = _category_for(space_data.get("space_type"))
        ModelClass = _MODEL_BY_CATEGORY[category]

        geom = None
        if space_data.get("polygon"):
            try:
                poly = Polygon(space_data["polygon"])
                geom = f"SRID=0;POLYGON(({', '.join([f'{x} {y}' for x, y in poly.exterior.coords])}))"
            except Exception as e:
                print(f"Error creating local polygon for {space_data['id']}: {e}")

        geom_global = None
        if space_data.get("polygon_global"):
            try:
                poly_global = Polygon(space_data["polygon_global"])
                geom_global = f"SRID=4326;POLYGON(({', '.join([f'{y} {x}' for x, y in poly_global.exterior.coords])}))"
            except Exception as e:
                print(f"Error creating global polygon for {space_data['id']}: {e}")

        existing = session.query(BuildingSpace).filter_by(
            id=space_data["id"]
        ).first()

        # If the category changed, remove the old row so the space lands
        # in the correct subclass table.
        if existing and existing.space_category != category:
            session.delete(existing)
            session.flush()
            existing = None

        if existing:
            record = existing
        else:
            record = ModelClass(id=space_data["id"])
            session.add(record)

        record.organization_id = space_data.get("organization_id")
        record.campus_id = space_data.get("campus_id")
        record.building_id = space_data.get("building_id")
        record.floor_id = space_data.get("floor_id")
        record.display_name = space_data.get("display_name")
        record.space_type = space_data.get("space_type")
        record.floor_index = space_data.get("floor_index")
        record.centroid_x = space_data.get("centroid_x")
        record.centroid_y = space_data.get("centroid_y")
        record.centroid_lat = space_data.get("centroid_lat")
        record.centroid_lng = space_data.get("centroid_lng")
        record.width_m = space_data.get("width_m")
        record.length_m = space_data.get("length_m")
        record.area_m2 = space_data.get("area_m2")
        record.is_accessible = space_data.get("is_accessible", True)
        record.is_navigable = space_data.get("is_navigable", True)
        record.is_outdoor = space_data.get("is_outdoor", False)
        record.capacity = space_data.get("capacity")
        record.tags = json.dumps(space_data.get("tags", []))
        record.meta_data = json.dumps(space_data.get("metadata", {}))
        if space_data.get("embedding") is not None:
            record.embedding = space_data["embedding"]
        if geom:
            record.geometry = geom
        if geom_global:
            record.geometry_global = geom_global
        record.updated_at = datetime.utcnow()

        session.commit()
        session.close()

    def sync_space_geometry(self, space_data: dict) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("sync_space_geometry", {"space_data": space_data})

    def _apply_sync_space_geometry(self, space_data: dict) -> None:
        session = self._open_session()
        record = session.query(BuildingSpace).filter_by(
            id=space_data["id"]
        ).first()
        if not record:
            session.close()
            return

        record.centroid_lat = space_data.get("centroid_lat")
        record.centroid_lng = space_data.get("centroid_lng")

        polygon_global = space_data.get("polygon_global")
        if polygon_global:
            try:
                poly_global = Polygon(polygon_global)
                record.geometry_global = (
                    "SRID=4326;POLYGON(("
                    + ", ".join(f"{y} {x}" for x, y in poly_global.exterior.coords)
                    + "))"
                )
            except Exception as e:
                print(f"Error creating global polygon for {space_data['id']}: {e}")
        else:
            record.geometry_global = None

        record.updated_at = datetime.utcnow()
        session.commit()
        session.close()

    # --- floors ---

    def sync_floor(self, floor_data: dict) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("sync_floor", {"floor_data": floor_data})

    def _apply_sync_floor(self, floor_data: dict) -> None:
        session = self._open_session()

        geom = None
        if floor_data.get("floor_plan_bounds"):
            try:
                bounds = floor_data["floor_plan_bounds"]
                if len(bounds) == 2:
                    min_x, min_y = bounds[0]
                    max_x, max_y = bounds[1]
                    poly_coords = [
                        (min_x, min_y), (max_x, min_y),
                        (max_x, max_y), (min_x, max_y), (min_x, min_y),
                    ]
                    geom = f"SRID=0;POLYGON(({', '.join([f'{x} {y}' for x, y in poly_coords])}))"
            except Exception as e:
                print(f"Error creating floor bounds polygon for {floor_data['id']}: {e}")

        record = session.query(Floor).filter_by(id=floor_data["id"]).first()
        if record:
            record.organization_id = floor_data.get("organization_id")
            record.display_name = floor_data.get("display_name")
            record.floor_plan_url = floor_data.get("floor_plan_url")
            record.floor_plan_scale = floor_data.get("floor_plan_scale", 1.0)
            record.floor_plan_origin_x = floor_data.get("floor_plan_origin_x", 0.0)
            record.floor_plan_origin_y = floor_data.get("floor_plan_origin_y", 0.0)
            if "is_public" in floor_data:
                record.is_public = bool(floor_data["is_public"])
            if geom:
                record.bounds_geometry = geom
            record.updated_at = datetime.utcnow()
        else:
            record = Floor(
                id=floor_data["id"],
                organization_id=floor_data.get("organization_id"),
                campus_id=floor_data.get("campus_id"),
                building_id=floor_data.get("building_id"),
                floor_id=floor_data.get("floor_id"),
                floor_index=floor_data.get("floor_index"),
                display_name=floor_data.get("display_name"),
                floor_plan_url=floor_data.get("floor_plan_url"),
                floor_plan_scale=floor_data.get("floor_plan_scale", 1.0),
                floor_plan_origin_x=floor_data.get("floor_plan_origin_x", 0.0),
                floor_plan_origin_y=floor_data.get("floor_plan_origin_y", 0.0),
                bounds_geometry=geom,
                is_public=bool(floor_data.get("is_public", False)),
            )
            session.add(record)

        session.commit()
        session.close()

    # Backwards-compatible alias (ImportService still calls this name).
    def sync_floor_plan(self, floor_data: dict) -> bool:
        return self.sync_floor(floor_data)

    # --- landmarks ---

    def sync_landmark(self, landmark_data: dict) -> bool:
        """Mirror a Neo4j Landmark write into PostGIS."""
        from services.sync_outbox import enqueue
        return enqueue("sync_landmark", {"landmark_data": landmark_data})

    def _apply_sync_landmark(self, landmark_data: dict) -> None:
        session = self._open_session()
        if session is None:
            return

        record = session.query(Landmark).filter_by(id=landmark_data["id"]).first()
        if record:
            record.name            = landmark_data.get("name", record.name)
            record.space_id        = landmark_data.get("space_id", record.space_id)
            record.floor_id        = landmark_data.get("floor_id", record.floor_id)
            record.building_id     = landmark_data.get("building_id", record.building_id)
            record.campus_id       = landmark_data.get("campus_id", record.campus_id)
            record.organization_id = landmark_data.get("organization_id", record.organization_id)
            if landmark_data.get("image_b64"):
                record.image_b64 = landmark_data["image_b64"]
            record.image_width     = landmark_data.get("image_width", record.image_width)
            record.image_height    = landmark_data.get("image_height", record.image_height)
            record.centroid_x      = landmark_data.get("centroid_x", record.centroid_x)
            record.centroid_y      = landmark_data.get("centroid_y", record.centroid_y)
            record.centroid_lat    = landmark_data.get("centroid_lat", record.centroid_lat)
            record.centroid_lng    = landmark_data.get("centroid_lng", record.centroid_lng)
            record.updated_at      = datetime.utcnow()
        else:
            record = Landmark(
                id=landmark_data["id"],
                name=landmark_data.get("name", ""),
                space_id=landmark_data["space_id"],
                floor_id=landmark_data.get("floor_id"),
                building_id=landmark_data.get("building_id"),
                campus_id=landmark_data.get("campus_id"),
                organization_id=landmark_data.get("organization_id"),
                image_b64=landmark_data.get("image_b64"),
                image_width=landmark_data.get("image_width"),
                image_height=landmark_data.get("image_height"),
                centroid_x=landmark_data.get("centroid_x"),
                centroid_y=landmark_data.get("centroid_y"),
                centroid_lat=landmark_data.get("centroid_lat"),
                centroid_lng=landmark_data.get("centroid_lng"),
                created_by=landmark_data.get("created_by"),
            )
            if landmark_data.get("created_at"):
                try:
                    iso = landmark_data["created_at"]
                    # Tolerate trailing Z by swapping to +00:00.
                    if isinstance(iso, str) and iso.endswith("Z"):
                        iso = iso[:-1] + "+00:00"
                    record.created_at = datetime.fromisoformat(iso) if isinstance(iso, str) else iso
                except (TypeError, ValueError):
                    pass
            session.add(record)

        session.commit()
        session.close()

    def delete_landmark(self, landmark_id: str) -> bool:
        from services.sync_outbox import enqueue
        return enqueue("delete_landmark", {"landmark_id": landmark_id})

    def _apply_delete_landmark(self, landmark_id: str) -> None:
        session = self._open_session()
        if session is None:
            return
        record = session.query(Landmark).filter_by(id=landmark_id).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    # --- deletes ---

    def delete_space(self, space_id: str) -> bool:
        """Remove a space from PostGIS. The FK cascade from the subclass
        table to building_spaces ensures both rows are cleaned up."""
        from services.sync_outbox import enqueue
        return enqueue("delete_space", {"space_id": space_id})

    def _apply_delete_space(self, space_id: str) -> None:
        session = self._open_session()
        record = session.query(BuildingSpace).filter_by(id=space_id).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    def delete_floor(self, floor_pk: str) -> bool:
        """Remove a floor row. `floor_pk` is the composed `{building_id}_{floor_id}`
        primary key used by the floors table (matches how sync_floor writes it)."""
        from services.sync_outbox import enqueue
        return enqueue("delete_floor", {"floor_pk": floor_pk})

    def _apply_delete_floor(self, floor_pk: str) -> None:
        session = self._open_session()
        record = session.query(Floor).filter_by(id=floor_pk).first()
        if record:
            session.delete(record)
            session.commit()
        session.close()

    def delete_floor_cascade(
        self,
        building_id: str,
        floor_id: str,
        space_ids: list[str],
    ) -> bool:
        """Delete every PostGIS row belonging to a single floor"""
        from services.sync_outbox import enqueue
        return enqueue("delete_floor_cascade", {
            "building_id": building_id,
            "floor_id": floor_id,
            "space_ids": list(space_ids),
        })

    def _apply_delete_floor_cascade(
        self,
        building_id: str,
        floor_id: str,
        space_ids: list[str],
    ) -> None:
        session = self._open_session()

        if space_ids:
            session.query(SpaceConnection).filter(
                or_(
                    SpaceConnection.from_space_id.in_(space_ids),
                    SpaceConnection.to_space_id.in_(space_ids),
                    SpaceConnection.door_space_id.in_(space_ids),
                    SpaceConnection.connection_group_id.in_(space_ids),
                )
            ).delete(synchronize_session=False)

            session.query(BuildingSpace).filter(
                BuildingSpace.id.in_(space_ids)
            ).delete(synchronize_session=False)

        session.query(Floor).filter_by(
            id=f"{building_id}_{floor_id}"
        ).delete(synchronize_session=False)

        session.commit()
        session.close()

    # --- connections ---

    def sync_connection(
        self,
        from_space_id: str,
        to_space_id: str,
        door_space_id: str,
        connection_type: str | None,
        is_accessible: bool = True,
        door_cx: float | None = None,
        door_cy: float | None = None,
    ) -> bool:
        """Mirror the four CONNECTS_TO edges produced by create_connection() as
        rows in space_connections."""
        from services.sync_outbox import enqueue
        return enqueue("sync_connection", {
            "from_space_id": from_space_id,
            "to_space_id": to_space_id,
            "door_space_id": door_space_id,
            "connection_type": connection_type,
            "is_accessible": is_accessible,
            "door_cx": door_cx,
            "door_cy": door_cy,
        })

    def _apply_sync_connection(
        self,
        from_space_id: str,
        to_space_id: str,
        door_space_id: str,
        connection_type: str | None,
        is_accessible: bool = True,
        door_cx: float | None = None,
        door_cy: float | None = None,
    ) -> None:
        session = self._open_session()
        group_id = door_space_id
        # Remove any pre-existing rows for this group (idempotent re-sync).
        session.query(SpaceConnection).filter_by(connection_group_id=group_id).delete()
        edges = [
            (from_space_id, door_space_id),
            (door_space_id, from_space_id),
            (to_space_id, door_space_id),
            (door_space_id, to_space_id),
        ]
        for idx, (a, b) in enumerate(edges):
            session.add(SpaceConnection(
                id=f"{group_id}:{idx}",
                connection_group_id=group_id,
                from_space_id=a,
                to_space_id=b,
                door_space_id=door_space_id,
                connection_type=connection_type,
                is_accessible=is_accessible,
                door_cx=door_cx,
                door_cy=door_cy,
            ))
        session.commit()
        session.close()

    def delete_connection_group(self, door_space_id: str) -> bool:
        """Delete all rows tied to a door's connection group."""
        from services.sync_outbox import enqueue
        return enqueue("delete_connection_group", {"door_space_id": door_space_id})

    def _apply_delete_connection_group(self, door_space_id: str) -> None:
        session = self._open_session()
        session.query(SpaceConnection).filter_by(connection_group_id=door_space_id).delete()
        session.commit()
        session.close()

    def sync_direct_edge(
        self,
        from_space_id: str,
        to_space_id: str,
        connection_type: str | None = None,
        is_accessible: bool = True,
        door_cx: float | None = None,
        door_cy: float | None = None,
    ) -> bool:
        """Mirror a single direct CONNECTS_TO edge (no intermediate door node)
        into space_connections. Used by bulk import where the schema describes
        edges directly rather than the door-node pattern."""
        from services.sync_outbox import enqueue
        return enqueue("sync_direct_edge", {
            "from_space_id": from_space_id,
            "to_space_id": to_space_id,
            "connection_type": connection_type,
            "is_accessible": is_accessible,
            "door_cx": door_cx,
            "door_cy": door_cy,
        })

    def _apply_sync_direct_edge(
        self,
        from_space_id: str,
        to_space_id: str,
        connection_type: str | None = None,
        is_accessible: bool = True,
        door_cx: float | None = None,
        door_cy: float | None = None,
    ) -> None:
        session = self._open_session()
        row_id = f"direct:{from_space_id}->{to_space_id}"
        existing = session.query(SpaceConnection).filter_by(id=row_id).first()
        if existing:
            existing.connection_type = connection_type
            existing.is_accessible = is_accessible
            if door_cx is not None and door_cy is not None:
                existing.door_cx = door_cx
                existing.door_cy = door_cy
        else:
            session.add(SpaceConnection(
                id=row_id,
                connection_group_id=None,
                from_space_id=from_space_id,
                to_space_id=to_space_id,
                door_space_id=None,
                connection_type=connection_type,
                is_accessible=is_accessible,
                door_cx=door_cx,
                door_cy=door_cy,
            ))
        session.commit()
        session.close()

    def get_direct_edge_door_positions(
        self,
        pairs: list[tuple[str, str]],
    ) -> dict[tuple[str, str], tuple[float, float]]:
        """Look up persisted door positions for a batch of direct edges."""
        if not self.engine or not settings.supabase_enable_sync or not pairs:
            return {}
        try:
            session = self._open_session()
            try:
                endpoints: set[str] = set()
                for a, b in pairs:
                    endpoints.add(a)
                    endpoints.add(b)
                rows = (
                    session.query(SpaceConnection)
                    .filter(
                        SpaceConnection.door_cx.isnot(None),
                        SpaceConnection.door_cy.isnot(None),
                        SpaceConnection.from_space_id.in_(endpoints),
                        SpaceConnection.to_space_id.in_(endpoints),
                    )
                    .all()
                )
            finally:
                session.close()
            out: dict[tuple[str, str], tuple[float, float]] = {}
            for r in rows:
                pos = (float(r.door_cx), float(r.door_cy))
                out[(r.from_space_id, r.to_space_id)] = pos
                out[(r.to_space_id, r.from_space_id)] = pos
            return out
        except Exception as e:
            print(f"Error fetching door positions: {e}")
            return {}

    def update_connection_door_position(
        self,
        from_space_id: str,
        to_space_id: str,
        door_cx: float,
        door_cy: float,
    ) -> bool:
        """Persist a user-placed door position to space_connections."""
        if not self.engine or not settings.supabase_enable_sync:
            return False
        try:
            session = self._open_session()
            try:
                # Direct-edge rows. There can be one row per direction.
                rows = (
                    session.query(SpaceConnection)
                    .filter(
                        or_(
                            (SpaceConnection.from_space_id == from_space_id) & (SpaceConnection.to_space_id == to_space_id),
                            (SpaceConnection.from_space_id == to_space_id) & (SpaceConnection.to_space_id == from_space_id),
                        )
                    )
                    .all()
                )
                touched = 0
                for r in rows:
                    r.door_cx = door_cx
                    r.door_cy = door_cy
                    touched += 1

                # Door-pattern rows are keyed by the door's id; find all
                # groups that link these two endpoints and update every row
                # in the group so reads via either side pick up the position.
                door_groups = (
                    session.query(SpaceConnection.connection_group_id)
                    .filter(
                        SpaceConnection.connection_group_id.isnot(None),
                        or_(
                            SpaceConnection.from_space_id == from_space_id,
                            SpaceConnection.from_space_id == to_space_id,
                            SpaceConnection.to_space_id == from_space_id,
                            SpaceConnection.to_space_id == to_space_id,
                        ),
                    )
                    .distinct()
                    .all()
                )
                group_ids = [g[0] for g in door_groups if g[0]]
                for gid in group_ids:
                    group_rows = session.query(SpaceConnection).filter_by(connection_group_id=gid).all()
                    endpoints = {r.from_space_id for r in group_rows} | {r.to_space_id for r in group_rows}
                    if from_space_id in endpoints and to_space_id in endpoints:
                        for r in group_rows:
                            r.door_cx = door_cx
                            r.door_cy = door_cy
                            touched += 1

                session.commit()
                return touched > 0
            finally:
                session.close()
        except Exception as e:
            print(f"Error updating door position {from_space_id}↔{to_space_id}: {e}")
            return False

    def list_campus_connections(self, campus_id: str) -> list[dict]:
        """Return every space_connections row whose `from_space_id` belongs
        to a space in this campus, in the import-compatible shape:
        `{from_space_id, to_space_id, connection_type, is_accessible}`."""
        if not self.engine or not settings.supabase_enable_sync:
            return []
        try:
            session = self._open_session()
            try:
                rows = session.execute(
                    text(
                        """
                        SELECT sc.from_space_id, sc.to_space_id,
                               sc.connection_type, sc.is_accessible,
                               sc.door_space_id,
                               sc.door_cx, sc.door_cy
                          FROM space_connections sc
                          JOIN building_spaces bs ON bs.id = sc.from_space_id
                         WHERE bs.campus_id = :campus_id
                        """
                    ),
                    {"campus_id": campus_id},
                ).all()
            finally:
                session.close()

            out: list[dict] = []
            seen: set[tuple] = set()

            for r in rows:
                from_id, to_id, ctype, is_acc, door_id, dcx, dcy = r[0], r[1], r[2], r[3], r[4], r[5], r[6]
                if door_id is None:
                    key = (from_id, to_id, ctype or "OPEN")
                    if key in seen:
                        continue
                    seen.add(key)
                    row: dict = {
                        "from_space_id": from_id,
                        "to_space_id": to_id,
                        "connection_type": ctype or "OPEN",
                        "is_accessible": bool(is_acc) if is_acc is not None else True,
                    }
                    if dcx is not None and dcy is not None:
                        row["door_cx"] = float(dcx)
                        row["door_cy"] = float(dcy)
                    out.append(row)

            door_groups: dict[str, list] = {}
            for r in rows:
                door_id = r[4]
                if door_id is None:
                    continue
                door_groups.setdefault(door_id, []).append(r)

            for door_id, group_rows in door_groups.items():
                endpoints: set[str] = set()
                group_conn_type = None
                group_access = None
                group_dcx = None
                group_dcy = None
                for r in group_rows:
                    a, b, ctype, is_acc, _, dcx, dcy = r[0], r[1], r[2], r[3], r[4], r[5], r[6]
                    if a != door_id:
                        endpoints.add(a)
                    if b != door_id:
                        endpoints.add(b)
                    if group_conn_type is None and ctype is not None:
                        group_conn_type = ctype
                    if group_access is None and is_acc is not None:
                        group_access = bool(is_acc)
                    if group_dcx is None and dcx is not None:
                        group_dcx = float(dcx)
                        group_dcy = float(dcy) if dcy is not None else None

                endpoints_list = list(endpoints)
                for i in range(len(endpoints_list)):
                    for j in range(len(endpoints_list)):
                        if i == j:
                            continue
                        a = endpoints_list[i]
                        b = endpoints_list[j]
                        key = (a, b, group_conn_type or "DOOR")
                        if key in seen:
                            continue
                        seen.add(key)
                        row = {
                            "from_space_id": a,
                            "to_space_id": b,
                            "connection_type": group_conn_type or "DOOR",
                            "is_accessible": group_access if group_access is not None else True,
                            "door_id": door_id,
                        }
                        if group_dcx is not None and group_dcy is not None:
                            row["door_cx"] = group_dcx
                            row["door_cy"] = group_dcy
                        out.append(row)

            return out
        except Exception as e:
            print(f"Error listing connections for campus {campus_id}: {e}")
            return []

    def delete_edges_for_space(self, space_id: str) -> bool:
        """Remove any space_connections rows touching the given space: edges
        where it's the endpoint, or where it's the door node of a door-pattern
        group. Used on space deletion to keep the mirror consistent."""
        from services.sync_outbox import enqueue
        return enqueue("delete_edges_for_space", {"space_id": space_id})

    def _apply_delete_edges_for_space(self, space_id: str) -> None:
        session = self._open_session()
        session.query(SpaceConnection).filter(
            (SpaceConnection.from_space_id == space_id)
            | (SpaceConnection.to_space_id == space_id)
            | (SpaceConnection.door_space_id == space_id)
            | (SpaceConnection.connection_group_id == space_id)
        ).delete(synchronize_session=False)
        session.commit()
        session.close()

    def update_connection_group_access(self, door_space_id: str, is_accessible: bool) -> bool:
        """Propagate a door's is_accessible change to every row in its
        connection group. No-op if the space isn't a door."""
        from services.sync_outbox import enqueue
        return enqueue("update_connection_group_access", {
            "door_space_id": door_space_id,
            "is_accessible": is_accessible,
        })

    def _apply_update_connection_group_access(
        self, door_space_id: str, is_accessible: bool,
    ) -> None:
        session = self._open_session()
        session.query(SpaceConnection).filter_by(
            connection_group_id=door_space_id
        ).update({SpaceConnection.is_accessible: is_accessible})
        session.commit()
        session.close()

    # --- imports ---

    def sync_import(
        self,
        campus_id: str,
        schema_version: str,
        payload: dict,
        organization_id: str | None = None,
    ) -> bool:
        """Store the raw import JSON payload keyed by campus_id."""
        from services.sync_outbox import enqueue
        return enqueue("sync_import", {
            "campus_id": campus_id,
            "schema_version": schema_version,
            "payload": payload,
            "organization_id": organization_id,
        })

    def _apply_sync_import(
        self,
        campus_id: str,
        schema_version: str,
        payload: dict,
        organization_id: str | None = None,
    ) -> None:
        session = self._open_session()
        record = session.query(ImportRecord).filter_by(
            campus_id=campus_id
        ).first()
        if record:
            if organization_id is not None:
                record.organization_id = organization_id
            record.schema_version = schema_version
            record.payload = payload
            record.imported_at = datetime.utcnow()
        else:
            record = ImportRecord(
                organization_id=organization_id,
                campus_id=campus_id,
                schema_version=schema_version,
                payload=payload,
            )
            session.add(record)
        session.commit()
        session.close()

    # --- reads ---

    def get_floor_plan(self, floor_id: str) -> dict | None:
        if not self.engine or not settings.supabase_enable_sync:
            return None

        try:
            session = self._open_session()
            record = session.query(Floor).filter_by(id=floor_id).first()
            if not record:
                session.close()
                return None

            bounds = None
            if record.bounds_geometry:
                try:
                    shape = to_shape(record.bounds_geometry)
                    bounds = [[x, y] for x, y in shape.exterior.coords]
                except Exception as e:
                    print(f"Error parsing floor bounds geometry: {e}")

            result = {
                "id": record.id,
                "campus_id": record.campus_id,
                "building_id": record.building_id,
                "floor_id": record.floor_id,
                "floor_index": record.floor_index,
                "display_name": record.display_name,
                "floor_plan_url": record.floor_plan_url,
                "floor_plan_scale": record.floor_plan_scale,
                "floor_plan_origin_x": record.floor_plan_origin_x,
                "floor_plan_origin_y": record.floor_plan_origin_y,
                "bounds": bounds,
            }
            session.close()
            return result
        except Exception as e:
            print(f"Error retrieving floor plan from PostGIS: {e}")
            return None

    def get_floor_spaces(self, floor_id: str) -> list[dict]:
        """Return all spaces for a floor across every subclass table,
        shaped to match the iOS SpaceDisplayItem contract."""
        if not self.engine or not settings.supabase_enable_sync:
            return []

        try:
            session = self._open_session()
            records = session.query(BuildingSpace).filter_by(
                floor_id=floor_id
            ).all()

            result = []
            for r in records:
                polygon_global = None
                if r.geometry_global is not None:
                    try:
                        shape = to_shape(r.geometry_global)
                        # PostGIS stores (lon, lat); iOS wants [[lat, lng], ...]
                        polygon_global = [[lat, lng] for lng, lat in shape.exterior.coords]
                    except Exception as e:
                        print(f"Error parsing geometry_global for {r.id}: {e}")

                polygon_local = None
                if r.geometry is not None:
                    try:
                        shape_local = to_shape(r.geometry)
                        polygon_local = [[x, y] for x, y in shape_local.exterior.coords]
                    except Exception as e:
                        print(f"Error parsing local geometry for {r.id}: {e}")

                result.append({
                    "id": r.id,
                    "display_name": r.display_name,
                    "space_type": r.space_type,
                    "space_category": r.space_category,
                    "floor_index": r.floor_index,
                    "centroid_x": r.centroid_x,
                    "centroid_y": r.centroid_y,
                    "centroid_lat": r.centroid_lat,
                    "centroid_lon": r.centroid_lng,  # iOS field name
                    "polygon": polygon_local,
                    "polygon_global": polygon_global,
                    "width_m": r.width_m,
                    "length_m": r.length_m,
                    "area_m2": r.area_m2,
                    "is_accessible": r.is_accessible,
                    "is_navigable": r.is_navigable,
                    "is_outdoor": r.is_outdoor,
                    "capacity": r.capacity,
                    "tags": json.loads(r.tags) if r.tags else [],
                    "metadata": json.loads(r.meta_data) if r.meta_data else {},
                    "building_id": r.building_id,
                })

            session.close()
            return result
        except Exception as e:
            print(f"Error retrieving floor spaces from PostGIS: {e}")
            return []

    def get_campus_spaces(self, campus_id: str) -> list[dict]:
        if not self.engine or not settings.supabase_enable_sync:
            return []

        try:
            session = self._open_session()
            records = session.query(BuildingSpace).filter_by(
                campus_id=campus_id
            ).all()
            result = [
                {
                    "id": r.id,
                    "display_name": r.display_name,
                    "space_type": r.space_type,
                    "space_category": r.space_category,
                    "floor_index": r.floor_index,
                    "centroid_x": r.centroid_x,
                    "centroid_y": r.centroid_y,
                    "width_m": r.width_m,
                    "length_m": r.length_m,
                    "area_m2": r.area_m2,
                    "is_accessible": r.is_accessible,
                    "is_navigable": r.is_navigable,
                    "is_outdoor": r.is_outdoor,
                    "capacity": r.capacity,
                    "tags": json.loads(r.tags) if r.tags else [],
                    "metadata": json.loads(r.meta_data) if r.meta_data else {},
                    "building_id": r.building_id,
                }
                for r in records
            ]
            session.close()
            return result
        except Exception as e:
            print(f"Error retrieving campus spaces from PostGIS: {e}")
            return []
