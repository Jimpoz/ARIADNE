import uuid

from db import Database
from models.map_import import MapImportSchema, SpaceImport, ConnectionNodeImport
from models.campus import (
    CampusCreate,
    BuildingCreate,
    FloorCreate,
    OrganizationCreate,
)
from models.space import SpaceCreate
from shared.models.enums import SpaceType
from repositories.campus_repo import CampusRepository, OrganizationRepository
from repositories.space_repo import SpaceRepository
from repositories.connection_repo import ConnectionRepository
from core.exceptions import SpaceNotFound
from services.geometry_service import (
    centroid_from_polygon,
    area_from_polygon,
    distance_m,
    compute_traversal_cost,
    find_shared_edge_midpoint,
    local_to_global_coordinates,
    polygon_local_to_global,
)
from services.postgis_service import PostGISService
from services.space_sync import build_space_sync_payload
from sentence_transformers import SentenceTransformer

embedder = SentenceTransformer("all-MiniLM-L6-v2")

class ImportService:
    def __init__(self, db: Database):
        self.org_repo = OrganizationRepository(db)
        self.campus_repo = CampusRepository(db)
        self.space_repo = SpaceRepository(db)
        self.conn_repo = ConnectionRepository(db)
        self.postgis = PostGISService()
        self._centroids: dict[str, tuple[float, float]] = {}

    def import_map(self, schema: MapImportSchema) -> dict:
        campus = schema.campus
        organization = schema.organization
        organization_id = None
        if organization is not None:
            existing_by_name = self._find_org_by_name(organization.name)
            if existing_by_name:
                organization_id = existing_by_name["id"]
                self.org_repo.create_organization(
                    OrganizationCreate(
                        id=organization_id,
                        name=organization.name,
                        entity_type=organization.entity_type,
                        description=organization.description,
                    )
                )
            else:
                organization_id = organization.id
                self.org_repo.create_organization(
                    OrganizationCreate(
                        id=organization.id,
                        name=organization.name,
                        entity_type=organization.entity_type,
                        description=organization.description,
                    )
                )
            self.postgis.sync_organization({
                "id": organization_id,
                "name": organization.name,
                "entity_type": organization.entity_type,
                "description": organization.description,
            })
        else:
            organization_id = campus.organization_id
            if organization_id:
                try:
                    existing_org = self.org_repo.get_organization(organization_id)
                    self.postgis.sync_organization({
                        "id": existing_org.get("id", organization_id),
                        "name": existing_org.get("name", organization_id),
                        "entity_type": existing_org.get("entity_type"),
                        "description": existing_org.get("description"),
                    })
                except Exception as exc:
                    print(
                        f"[ImportService] Could not backfill organization "
                        f"{organization_id} into PostGIS: {exc}"
                    )

        self.postgis.sync_import(
            campus_id=campus.id,
            schema_version=schema.schema_version,
            payload=schema.model_dump(mode="json"),
            organization_id=organization_id,
        )

        # 1. Campus
        self.campus_repo.create_campus(
            CampusCreate(
                id=campus.id,
                name=campus.name,
                description=campus.description,
                organization_id=organization_id,
                is_public=bool(campus.is_public),
            )
        )
        self.postgis.sync_campus({
            "id": campus.id,
            "organization_id": organization_id,
            "name": campus.name,
            "description": campus.description,
            "is_public": campus.is_public,
        })

        # 2. Buildings → Floors → Spaces
        for building in campus.buildings:
            building_org_id = building.organization_id or organization_id
            building_is_public = bool(building.is_public or campus.is_public)
            self.campus_repo.create_building(
                BuildingCreate(
                    id=building.id,
                    campus_id=campus.id,
                    organization_id=building_org_id,
                    name=building.name,
                    short_name=building.short_name,
                    address=building.address,
                    origin_lat=building.origin_lat,
                    origin_lng=building.origin_lng,
                    origin_bearing=building.origin_bearing,
                    floor_count=building.floor_count,
                )
            )
            self.postgis.sync_building({
                "id": building.id,
                "campus_id": campus.id,
                "organization_id": building_org_id,
                "name": building.name,
                "short_name": building.short_name,
                "address": building.address,
                "origin_lat": building.origin_lat,
                "origin_lng": building.origin_lng,
                "origin_bearing": building.origin_bearing,
                "floor_count": building.floor_count,
                "is_public": building_is_public,
            })
            for floor in building.floors:
                floor_is_public = (
                    bool(floor.is_public) if floor.is_public is not None else building_is_public
                )
                self.campus_repo.create_floor(
                    FloorCreate(
                        id=floor.id,
                        building_id=building.id,
                        floor_index=floor.floor_index,
                        display_name=floor.display_name,
                        elevation_m=floor.elevation_m,
                        floor_plan_url=floor.floor_plan_url,
                        floor_plan_scale=floor.floor_plan_scale,
                        floor_plan_origin_x=floor.floor_plan_origin_x,
                        floor_plan_origin_y=floor.floor_plan_origin_y,
                    )
                )

                self.postgis.sync_floor({
                    "id": f"{building.id}_{floor.id}",
                    "organization_id": building_org_id,
                    "campus_id": campus.id,
                    "building_id": building.id,
                    "floor_id": floor.id,
                    "floor_index": floor.floor_index,
                    "display_name": floor.display_name,
                    "floor_plan_url": floor.floor_plan_url,
                    "floor_plan_scale": floor.floor_plan_scale,
                    "floor_plan_origin_x": floor.floor_plan_origin_x,
                    "floor_plan_origin_y": floor.floor_plan_origin_y,
                    "floor_plan_bounds": floor.floor_plan_bounds,
                    "is_public": floor_is_public,
                })

                for space in floor.spaces:
                    self._import_space(
                        space,
                        floor_id=floor.id,
                        building_id=building.id,
                        campus_id=campus.id,
                        organization_id=building_org_id,
                        floor_index=floor.floor_index,
                        parent_id=None,
                    )

        # 3. Outdoor spaces (no floor/building context)
        for space in campus.outdoor_spaces:
            self._import_space(
                space,
                floor_id=None,
                building_id=None,
                campus_id=campus.id,
                organization_id=organization_id,
                floor_index=None,
                parent_id=None,
            )

        counts = {
            "spaces": len(self._centroids),
            "connections": 0,
            "connections_skipped": 0,
        }
        endpoint_ids = list({
            cid
            for conn in campus.connections
            for cid in (conn.from_space_id, conn.to_space_id)
            if cid
        })
        known_space_ids: set[str] = set()
        if endpoint_ids:
            rows = self.space_repo.db.execute(
                "MATCH (s:Space) WHERE s.id IN $ids RETURN s.id AS id",
                {"ids": endpoint_ids},
            )
            known_space_ids = {r["id"] for r in rows if r.get("id")}

        for conn in campus.connections:
            if (
                conn.from_space_id not in known_space_ids
                or conn.to_space_id not in known_space_ids
            ):
                counts["connections_skipped"] += 1
                continue
            try:
                self._import_connection_node(conn)
                counts["connections"] += 1
            except Exception as exc:
                counts["connections_skipped"] += 1
                print(
                    f"[ImportService] Skipped connection "
                    f"{conn.from_space_id}→{conn.to_space_id}: {exc}"
                )

        return {
            "organization_id": organization_id,
            "campus_id": campus.id,
            "spaces_imported": counts["spaces"],
            "connections_imported": counts["connections"],
            "connections_skipped": counts["connections_skipped"],
        }

    def _find_org_by_name(self, name: str) -> dict | None:
        """Case-insensitive lookup by Organization.name.

        Used by import_map so re-imports of the same institution under a
        different id don't fork into a duplicate organization. Returns
        the first match (sorted by id for determinism) or None if no
        organization shares the name."""
        if not name:
            return None
        rows = self.org_repo.db.execute(
            """
            MATCH (o:Organization)
            WHERE toLower(o.name) = toLower($name)
            RETURN o
            ORDER BY o.id ASC
            LIMIT 1
            """,
            {"name": name},
        )
        if rows:
            org = rows[0]["o"]
            return dict(org) if not isinstance(org, dict) else org
        return None

    def _import_space(
        self,
        space: SpaceImport,
        floor_id: str | None,
        building_id: str | None,
        campus_id: str,
        organization_id: str | None,
        floor_index: int | None,
        parent_id: str | None,
    ) -> None:
        cx, cy = space.centroid_x, space.centroid_y
        area = space.area_m2

        if space.polygon and (cx is None or cy is None):
            cx, cy = centroid_from_polygon(space.polygon)
        if space.polygon and area is None:
            area = area_from_polygon(space.polygon)

        if cx is not None and cy is not None:
            self._centroids[space.id] = (cx, cy)

        global_lat, global_lng = None, None
        global_polygon = None

        if building_id and cx is not None and cy is not None:
            building = self.campus_repo.get_building(building_id)
            if building.get("origin_lat") is not None and building.get("origin_lng") is not None:
                global_lat, global_lng = local_to_global_coordinates(
                    cx, cy,
                    building["origin_lat"],
                    building["origin_lng"],
                    building.get("origin_bearing") or 0.0
                )

                if space.polygon:
                    global_polygon = polygon_local_to_global(
                        space.polygon,
                        building["origin_lat"],
                        building["origin_lng"],
                        building.get("origin_bearing") or 0.0
                    )

        text_to_embed = f"{space.display_name}. Type: {space.space_type}. Tags: {' '.join(space.tags)}"

        vector = embedder.encode([text_to_embed])[0].tolist()

        traversal_cost = compute_traversal_cost(
            space.space_type.value if hasattr(space.space_type, 'value') else str(space.space_type),
            space.width_m,
            space.length_m,
            None,
        )

        self.space_repo.create_space(
            SpaceCreate(
                id=space.id,
                display_name=space.display_name,
                short_name=space.short_name,
                space_type=space.space_type,
                floor_index=floor_index,
                building_id=building_id,
                campus_id=campus_id,
                organization_id=organization_id,
                floor_id=floor_id,
                parent_space_id=parent_id,
                width_m=space.width_m,
                length_m=space.length_m,
                area_m2=area,
                centroid_x=cx,
                centroid_y=cy,
                centroid_lat=global_lat,
                centroid_lng=global_lng,
                polygon=space.polygon,
                polygon_global=global_polygon,
                is_accessible=space.is_accessible,
                is_navigable=space.is_navigable,
                is_outdoor=space.is_outdoor,
                capacity=space.capacity,
                tags=space.tags,
                metadata=space.metadata,
                embedding=vector,
                traversal_cost=traversal_cost,
            )
        )

        # Sync to PostGIS with global coordinates
        self.postgis.sync_space({
            "id": space.id,
            "organization_id": organization_id,
            "campus_id": campus_id,
            "building_id": building_id,
            "floor_id": floor_id,
            "display_name": space.display_name,
            "space_type": space.space_type.value if hasattr(space.space_type, 'value') else str(space.space_type),
            "floor_index": floor_index,
            "centroid_x": cx,
            "centroid_y": cy,
            "centroid_lat": global_lat,
            "centroid_lng": global_lng,
            "width_m": space.width_m,
            "length_m": space.length_m,
            "area_m2": area,
            "polygon": space.polygon,
            "polygon_global": global_polygon,
            "is_accessible": space.is_accessible,
            "is_navigable": space.is_navigable,
            "is_outdoor": space.is_outdoor,
            "capacity": space.capacity,
            "tags": space.tags,
            "metadata": space.metadata,
            "embedding": vector,
        })

        for subspace in space.subspaces:
            self._import_space(
                subspace,
                floor_id=floor_id,
                building_id=building_id,
                campus_id=campus_id,
                organization_id=organization_id,
                floor_index=floor_index,
                parent_id=space.id,
            )

    def _import_connection_node(self, conn: ConnectionNodeImport) -> None:
        ct = (
            conn.connection_type.value
            if hasattr(conn.connection_type, "value")
            else (str(conn.connection_type) if conn.connection_type is not None else None)
        )
        ct_upper = (ct or "").upper()

        # Door-pattern types: materialize a door Space at the midpoint and
        # four bidirectional edges, mirroring routes/connections.py POST.
        if ct_upper in {"DOOR", "DOORWAY", "PASSAGE"}:
            self._create_door_space_connection(conn, ct_upper)
            return

        # Other types (STAIRCASE_*, ELEVATOR_*, ESCALATOR, RAMP, OPEN, ...)
        # remain direct A→B edges.
        self.conn_repo.create_connection(conn.from_space_id, conn.to_space_id)
        self.postgis.sync_direct_edge(
            from_space_id=conn.from_space_id,
            to_space_id=conn.to_space_id,
            connection_type=ct,
            is_accessible=bool(getattr(conn, "is_accessible", True)),
            door_cx=getattr(conn, "door_cx", None),
            door_cy=getattr(conn, "door_cy", None),
        )

    def _create_door_space_connection(
        self,
        conn: ConnectionNodeImport,
        ct_upper: str,
    ) -> None:
        space_a = self.space_repo.get_space(conn.from_space_id)
        space_b = self.space_repo.get_space(conn.to_space_id)

        # Door midpoint: prefer explicit coords from the import, else
        # shared-edge midpoint, else centroid average.
        cx, cy = conn.door_cx, conn.door_cy
        if cx is None or cy is None:
            poly_a = space_a.get("polygon")
            poly_b = space_b.get("polygon")
            if poly_a and poly_b:
                mid = find_shared_edge_midpoint(poly_a, poly_b)
                if mid:
                    cx, cy = mid
        if cx is None or cy is None:
            cx_a, cy_a = space_a.get("centroid_x"), space_a.get("centroid_y")
            cx_b, cy_b = space_b.get("centroid_x"), space_b.get("centroid_y")
            if all(v is not None for v in (cx_a, cy_a, cx_b, cy_b)):
                cx = (cx_a + cx_b) / 2.0
                cy = (cy_a + cy_b) / 2.0

        # Pick a SpaceType for the door from connection_type + door_type.
        door_type_str = (
            conn.door_type.value if hasattr(conn.door_type, "value")
            else (str(conn.door_type) if conn.door_type is not None else None)
        )
        if ct_upper == "PASSAGE":
            door_space_type = SpaceType.PASSAGE
        else:
            door_space_type = {
                "STANDARD": SpaceType.DOOR_STANDARD,
                "AUTOMATIC": SpaceType.DOOR_AUTOMATIC,
                "LOCKED": SpaceType.DOOR_LOCKED,
                "EMERGENCY": SpaceType.DOOR_EMERGENCY,
            }.get((door_type_str or "").upper(), SpaceType.DOOR_STANDARD)

        # Match the convention from routes/connections.py: floor_id is set
        # only when both endpoints share the same floor.
        floor_a = space_a.get("floor_id")
        floor_b = space_b.get("floor_id")
        floor_id = floor_a if floor_a == floor_b else None
        floor_index = space_a.get("floor_index") if floor_a == floor_b else None
        building_id = space_a.get("building_id")
        if space_b.get("building_id") != building_id:
            building_id = None
        campus_id = space_a.get("campus_id")
        organization_id = space_a.get("organization_id") or space_b.get("organization_id")

        # Carry connection-level metadata onto the door Space's metadata so
        # it round-trips on re-export.
        meta: dict = {}
        if conn.requires_access_level is not None:
            meta["requires_access_level"] = conn.requires_access_level
        if conn.transition_time_s is not None:
            meta["transition_time_s"] = conn.transition_time_s
        if conn.weight_override is not None:
            meta["weight_override"] = conn.weight_override

        sorted_endpoints = sorted([conn.from_space_id, conn.to_space_id])
        door_id_seed = f"{ct_upper}:{sorted_endpoints[0]}:{sorted_endpoints[1]}"
        door_id = f"door_{uuid.uuid5(uuid.NAMESPACE_URL, door_id_seed).hex[:12]}"
        traversal_cost = compute_traversal_cost(door_space_type.value, None, None, None)

        # Compute global coords if the building has an origin.
        global_lat, global_lng = None, None
        if building_id and cx is not None and cy is not None:
            building = self.campus_repo.get_building(building_id)
            if building.get("origin_lat") is not None and building.get("origin_lng") is not None:
                global_lat, global_lng = local_to_global_coordinates(
                    cx, cy, building["origin_lat"], building["origin_lng"],
                    building.get("origin_bearing") or 0.0,
                )

        for stale_id in self.conn_repo.find_door_spaces_between(
            conn.from_space_id, conn.to_space_id
        ):
            if stale_id == door_id:
                continue
            try:
                self.space_repo.delete_space(stale_id)
            except SpaceNotFound:
                pass
            self.postgis.delete_space(stale_id)

        is_accessible = bool(getattr(conn, "is_accessible", True))
        door_space = self.space_repo.create_space(
            SpaceCreate(
                id=door_id,
                display_name=door_space_type.value.replace("_", " ").title(),
                space_type=door_space_type,
                campus_id=campus_id,
                building_id=building_id,
                floor_id=floor_id,
                floor_index=floor_index,
                organization_id=organization_id,
                centroid_x=cx,
                centroid_y=cy,
                centroid_lat=global_lat,
                centroid_lng=global_lng,
                is_accessible=is_accessible,
                is_navigable=True,
                traversal_cost=traversal_cost,
                metadata=meta or None,
            )
        )
        self.postgis.sync_space(build_space_sync_payload(door_space, self.campus_repo))

        self.conn_repo.create_connection(conn.from_space_id, door_id)
        self.conn_repo.create_connection(door_id, conn.from_space_id)
        self.conn_repo.create_connection(conn.to_space_id, door_id)
        self.conn_repo.create_connection(door_id, conn.to_space_id)

        self.postgis.sync_connection(
            from_space_id=conn.from_space_id,
            to_space_id=conn.to_space_id,
            door_space_id=door_id,
            connection_type=door_space_type.value,
            is_accessible=is_accessible,
            door_cx=cx,
            door_cy=cy,
        )
