from typing import Optional
from pydantic import BaseModel

from shared.models.enums import EntityType


class OrganizationCreate(BaseModel):
    id: str
    name: str
    entity_type: EntityType = EntityType.OTHER
    description: Optional[str] = None


class Organization(BaseModel):
    id: str
    name: str
    entity_type: EntityType = EntityType.OTHER
    description: Optional[str] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class CampusCreate(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    organization_id: Optional[str] = None
    is_public: bool = False


class Campus(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    organization_id: Optional[str] = None
    is_public: bool = False
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class VisibleCampus(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    organization_id: Optional[str] = None
    organization_name: Optional[str] = None
    is_public: bool = False


class VisibleBuilding(BaseModel):
    id: str
    name: str
    short_name: Optional[str] = None
    address: Optional[str] = None
    campus_id: str
    campus_name: Optional[str] = None
    organization_id: Optional[str] = None
    organization_name: Optional[str] = None
    is_public: bool = False
    origin_lat: float
    origin_lng: float


class BuildingCreate(BaseModel):
    id: str
    campus_id: str
    organization_id: Optional[str] = None
    name: str
    short_name: Optional[str] = None
    address: Optional[str] = None
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: float = 0.0
    scale_factor: float = 1.0
    floor_count: Optional[int] = None


class BuildingUpdate(BaseModel):
    """Georeferencing edit: reposition / rotate / resize a building."""
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: Optional[float] = None
    scale_factor: Optional[float] = None


class Building(BaseModel):
    id: str
    campus_id: str
    organization_id: Optional[str] = None
    name: str
    short_name: Optional[str] = None
    address: Optional[str] = None
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: Optional[float] = None
    scale_factor: float = 1.0
    floor_count: Optional[int] = None
    created_at: Optional[str] = None
    updated_at: Optional[str] = None


class FloorCreate(BaseModel):
    id: str
    building_id: str
    floor_index: int
    display_name: str
    elevation_m: Optional[float] = None
    floor_plan_url: Optional[str] = None
    floor_plan_scale: Optional[float] = None
    floor_plan_origin_x: Optional[float] = None
    floor_plan_origin_y: Optional[float] = None


class FloorUpdate(BaseModel):
    """Per-floor georeferencing edit."""
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: Optional[float] = None
    scale_factor: Optional[float] = None


class Floor(BaseModel):
    id: str
    building_id: str
    floor_index: int
    display_name: str
    elevation_m: Optional[float] = None
    floor_plan_url: Optional[str] = None
    floor_plan_scale: Optional[float] = None
    floor_plan_origin_x: Optional[float] = None
    floor_plan_origin_y: Optional[float] = None
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: Optional[float] = None
    scale_factor: Optional[float] = None
