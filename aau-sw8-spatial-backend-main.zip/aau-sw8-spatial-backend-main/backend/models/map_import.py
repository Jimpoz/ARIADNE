from typing import Optional, Union
from pydantic import BaseModel, Field, model_validator, validator
from shared.models.enums import ConnectionType, DoorType, SpaceType, EntityType


class OrganizationImport(BaseModel):
    """Organization/entity context for the import."""
    id: str
    name: str
    entity_type: EntityType = EntityType.OTHER
    description: Optional[str] = None


class SpaceImport(BaseModel):
    id: str
    display_name: str
    short_name: Optional[str] = None
    space_type: Union[SpaceType, str]  # Allow string that will be converted
    centroid_x: Optional[float] = None
    centroid_y: Optional[float] = None
    polygon: Optional[list[list[float]]] = None
    width_m: Optional[float] = None
    length_m: Optional[float] = None
    area_m2: Optional[float] = None
    is_accessible: bool = True
    is_navigable: bool = True
    is_outdoor: bool = False
    capacity: Optional[int] = None
    tags: list[str] = []
    metadata: Optional[dict] = None
    subspaces: list["SpaceImport"] = []

    @validator('space_type', pre=True)
    def validate_space_type(cls, v):
        if isinstance(v, str):
            return SpaceType(v) 
        return v

    @validator('polygon', pre=True)
    def validate_polygon(cls, v):
        if v is None:
            return v
        if isinstance(v, list) and len(v) > 0:
            try:
                return [[float(coord[0]), float(coord[1])] for coord in v]
            except (IndexError, TypeError, ValueError):
                raise ValueError("Polygon must be a list of [x, y] coordinate pairs")
        return v


SpaceImport.model_rebuild()


class FloorImport(BaseModel):
    id: str
    floor_index: int
    display_name: str
    elevation_m: Optional[float] = None
    floor_plan_url: Optional[str] = None
    floor_plan_scale: Optional[float] = Field(default=1.0)
    floor_plan_origin_x: Optional[float] = Field(default=0.0)
    floor_plan_origin_y: Optional[float] = Field(default=0.0)
    spaces: list[SpaceImport] = []
    floor_plan_bounds: Optional[list[list[float]]] = None
    is_public: Optional[bool] = None


class BuildingImport(BaseModel):
    id: str
    name: str
    short_name: Optional[str] = None
    address: Optional[str] = None
    organization_id: Optional[str] = None
    origin_lat: Optional[float] = None
    origin_lng: Optional[float] = None
    origin_bearing: float = 0.0
    floor_count: Optional[int] = None
    floors: list[FloorImport] = []
    building_bounds: Optional[list[list[float]]] = None
    is_public: bool = False


class ConnectionNodeImport(BaseModel):
    from_space_id: str
    to_space_id: str
    connection_type: Union[ConnectionType, str]
    is_accessible: bool = True
    door_type: Union[DoorType, str, None] = None
    requires_access_level: Optional[str] = None
    transition_time_s: Optional[float] = None
    weight_override: Optional[float] = None
    door_cx: Optional[float] = None
    door_cy: Optional[float] = None
    door_cx: Optional[float] = None
    door_cy: Optional[float] = None

    @validator('connection_type', pre=True)
    def validate_connection_type(cls, v):
        if isinstance(v, str):
            up = v.upper()
            if up.startswith("DOOR_") and up != "DOOR_TYPE":
                return ConnectionType.DOOR
            return ConnectionType(up)
        return v

    @validator('door_type', pre=True)
    def validate_door_type(cls, v):
        if v is None or isinstance(v, DoorType):
            return v
        if isinstance(v, str):
            if v.upper() == "NONE":
                return None
            return DoorType(v.upper())
        return v

    @model_validator(mode="before")
    @classmethod
    def _recover_door_type_from_legacy_connection_type(cls, data):
        if not isinstance(data, dict):
            return data
        ct = data.get("connection_type")
        if isinstance(ct, str) and ct.upper().startswith("DOOR_"):
            suffix = ct.upper().split("DOOR_", 1)[1]
            if not data.get("door_type"):
                data["door_type"] = suffix
        return data


class CampusImport(BaseModel):
    id: str
    name: str
    description: Optional[str] = None
    organization_id: Optional[str] = None
    buildings: list[BuildingImport] = []
    outdoor_spaces: list[SpaceImport] = []
    connections: list[ConnectionNodeImport] = []
    is_public: bool = False


class MapImportSchema(BaseModel):
    schema_version: str = "1.0"
    organization: Optional[OrganizationImport] = None
    campus: CampusImport
