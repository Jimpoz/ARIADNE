import asyncio
import os
from typing import Any

import httpx
import jwt
import websockets
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

BACKEND_URL = os.getenv("BACKEND_URL", "http://backend:8000")
ASSISTANT_URL = os.getenv("ASSISTANT_URL", "http://assistant:8001")
IMAGE_PIPELINE_URL = os.getenv("IMAGE_PIPELINE_URL", "http://image_pipeline:8002")
ML_VISION_URL = os.getenv("ML_VISION_URL", "http://ml_vision:8000")
API_SECRET = os.getenv("API_SECRET", "")
AUTH_JWT_SECRET = os.getenv("AUTH_JWT_SECRET", "")
AUTH_JWT_ISSUER = os.getenv("AUTH_JWT_ISSUER", "ariadne-backend")
_IDENTITY_HEADERS = ("x-user-id", "x-org-id", "x-org-ids", "x-user-role")

_STRIP_RESPONSE_HEADERS = frozenset({
    "date", "server", "content-length",
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade",
})


def _relay_headers(upstream_headers: Any, upstream_name: str) -> dict[str, str]:
    out = {
        k: v for k, v in upstream_headers.items()
        if k.lower() not in _STRIP_RESPONSE_HEADERS
    }
    out["X-Gateway-Upstream"] = upstream_name
    return out


def _env_flag(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in {"1", "true", "yes", "on"}


MIDDLEWARE_DEBUG_UPSTREAMS = _env_flag("MIDDLEWARE_DEBUG_UPSTREAMS")
ALLOW_IDENTITY_PASSTHROUGH = _env_flag("ALLOW_IDENTITY_PASSTHROUGH")


class CampusListItem(BaseModel):
    id: str
    name: str

OPENAPI_SOURCES = (
    {
        "name": "backend",
        "base_url": BACKEND_URL,
        "public_prefixes": ("/api/v1/",),
        "exclude_prefixes": ("/api/v1/assistant/", "/api/v1/room-summary"),
    },
    {
        "name": "assistant",
        "base_url": ASSISTANT_URL,
        "public_prefixes": ("/api/v1/assistant/",),
        "exclude_prefixes": (),
    },
    {
        "name": "image_pipeline",
        "base_url": IMAGE_PIPELINE_URL,
        "public_prefixes": ("/api/v1/room-summary",),
        "exclude_prefixes": (),
    },
    {
        "name": "ml_vision",
        "base_url": ML_VISION_URL,
        "public_prefixes": ("/api/v1/ml-vision",),
        "exclude_prefixes": (),
    },
)

_UNPROTECTED_PATHS = {"/health"}


app = FastAPI(
    title="Indoor Navigation Gateway",
    version="1.0.0",
    description=(
        "Gateway for backend, assistant, and image pipeline services. "
        "The docs show middleware-owned routes only."
    ),
    openapi_tags=[
        {"name": "mobile", "description": "Lightweight endpoints for mobile clients."},
    ]
    + (
        [{"name": "debug", "description": "Gateway-level debugging and upstream inspection."}]
        if MIDDLEWARE_DEBUG_UPSTREAMS
        else []
    ),
)


@app.middleware("http")
async def verify_api_key(request: Request, call_next):
    if request.url.path in _UNPROTECTED_PATHS:
        return await call_next(request)
    if not API_SECRET or request.headers.get("X-Api-Key") != API_SECRET:
        return Response(
            content=b'{"detail":"Unauthorized"}',
            status_code=401,
            headers={"Content-Type": "application/json"},
        )
    return await call_next(request)


async def _probe_url(client: httpx.AsyncClient, url: str) -> dict[str, Any]:
    try:
        response = await client.get(url)
        return {"ok": response.status_code == 200, "status_code": response.status_code}
    except Exception as exc:
        return {"ok": False, "status_code": None, "error": str(exc)}


def _decode_identity(authorization: str | None) -> dict | None:
    """Verify a bearer JWT against AUTH_JWT_SECRET and return the claims, or
    None if no token is present / verification fails. Failures are silent in
    Slice 1 — the request still goes through, just without identity headers.
    A future slice will start failing closed for protected endpoints."""
    if not AUTH_JWT_SECRET or not authorization:
        return None
    if not authorization.lower().startswith("bearer "):
        return None
    token = authorization.split(" ", 1)[1].strip()
    try:
        return jwt.decode(
            token,
            AUTH_JWT_SECRET,
            algorithms=["HS256"],
            issuer=AUTH_JWT_ISSUER,
            options={"require": ["exp", "sub"]},
        )
    except jwt.InvalidTokenError:
        return None


def _apply_identity_headers(headers: dict[str, str], claims: dict | None) -> None:
    """Strip any caller-supplied identity headers (anti-spoofing) and, when a
    JWT was successfully decoded, stamp the trusted values from the claims.
    Mutates `headers` in place."""
    # If JWT auth is not configured, allow caller-supplied identity headers
    # to pass through when no JWT claims were decoded. This makes local
    # development easier — clients can set `x-org-ids` manually — while
    # preserving anti-spoofing when a JWT secret is configured.
    if not AUTH_JWT_SECRET:
        if not claims:
            return
        # If claims are present even in dev mode, override any incoming headers.
        for h in _IDENTITY_HEADERS:
            headers.pop(h, None)
            headers.pop(h.title(), None)
    else:
        # Production / secured mode: by default strip identity headers first.
        # Optionally allow caller-supplied identity headers to pass through
        # when no Authorization header is present and the env flag is set.
        auth_present = bool(headers.get("authorization") or headers.get("Authorization"))
        if not claims and ALLOW_IDENTITY_PASSTHROUGH and not auth_present:
            # Let caller-supplied identity headers pass through (dev convenience).
            return
        for h in _IDENTITY_HEADERS:
            headers.pop(h, None)
            headers.pop(h.title(), None)

    if not claims:
        return

    if claims.get("sub"):
        headers["x-user-id"] = str(claims["sub"])
    if claims.get("org_id"):
        headers["x-org-id"] = str(claims["org_id"])
    org_ids = claims.get("org_ids")
    if isinstance(org_ids, list) and org_ids:
        # CSV — single header, parsed back into a list at the backend.
        headers["x-org-ids"] = ",".join(str(o) for o in org_ids if o)
    if claims.get("role"):
        headers["x-user-role"] = str(claims["role"])


async def _proxy(request: Request, target_base: str, upstream_name: str) -> Response:
    path = request.url.path
    query = str(request.url.query)
    url = f"{target_base}{path}"
    if query:
        url = f"{url}?{query}"

    body = await request.body()
    headers = dict(request.headers)
    headers.pop("host", None)
    _apply_identity_headers(
        headers, _decode_identity(request.headers.get("authorization")),
    )

    try:
        async with httpx.AsyncClient(timeout=900.0) as client:
            resp = await client.request(
                method=request.method,
                url=url,
                headers=headers,
                content=body,
            )
    except httpx.HTTPError:
        return Response(
            content=f'{{"detail":"{upstream_name} unavailable"}}'.encode(),
            status_code=502,
            headers={"Content-Type": "application/json"},
        )

    return Response(
        content=resp.content,
        status_code=resp.status_code,
        headers=_relay_headers(resp.headers, upstream_name),
    )


def _strip_space_images(space: dict) -> None:
    if "room_images" in space:
        space["room_images"] = []
    metadata = space.get("metadata")
    if isinstance(metadata, dict):
        rs = metadata.get("room_summary")
        if isinstance(rs, dict):
            rs["room_images"] = []
            for view in rs.get("views", []):
                if isinstance(view, dict):
                    view.pop("svg", None)
    for subspace in space.get("subspaces", []):
        _strip_space_images(subspace)


def _strip_image_data(data: dict) -> None:
    campus = data.get("campus")
    if not campus:
        return
    for building in campus.get("buildings", []):
        for floor in building.get("floors", []):
            for space in floor.get("spaces", []):
                _strip_space_images(space)


async def debug_upstreams() -> dict[str, Any]:
    async with httpx.AsyncClient(timeout=5.0) as client:
        upstreams = []
        for source in OPENAPI_SOURCES:
            health = await _probe_url(client, f"{source['base_url']}/health")
            openapi = await _probe_url(client, f"{source['base_url']}/openapi.json")
            upstreams.append(
                {
                    "name": source["name"],
                    "base_url": source["base_url"],
                    "public_prefixes": list(source["public_prefixes"]),
                    "health": health,
                    "openapi": openapi,
                }
            )

    return {
        "gateway_docs": {
            "docs_url": "/docs",
            "openapi_url": "/openapi.json",
            "health_url": "/health",
        },
        "upstreams": upstreams,
    }


if MIDDLEWARE_DEBUG_UPSTREAMS:
    app.get("/debug/upstreams", tags=["debug"])(debug_upstreams)


@app.get("/health")
async def health():
    backend_ok = False
    assistant_ok = False
    image_pipeline_ok = False
    ml_vision_ok = False

    async with httpx.AsyncClient(timeout=5.0) as client:
        try:
            r = await client.get(f"{BACKEND_URL}/health")
            backend_ok = r.status_code == 200
        except Exception:
            pass
        try:
            r = await client.get(f"{ASSISTANT_URL}/health")
            assistant_ok = r.status_code == 200
        except Exception:
            pass
        try:
            r = await client.get(f"{IMAGE_PIPELINE_URL}/health")
            image_pipeline_ok = r.status_code == 200
        except Exception:
            pass
        try:
            r = await client.get(f"{ML_VISION_URL}/health")
            ml_vision_ok = r.status_code == 200
        except Exception:
            pass

    return {
        "status": "ok" if backend_ok and assistant_ok and image_pipeline_ok and ml_vision_ok else "degraded",
        "backend": "ok" if backend_ok else "unavailable",
        "assistant": "ok" if assistant_ok else "unavailable",
        "image_pipeline": "ok" if image_pipeline_ok else "unavailable",
        "ml_vision": "ok" if ml_vision_ok else "unavailable",
    }


@app.get("/api/v1/mobile/campuses", response_model=list[CampusListItem], tags=["mobile"])
async def mobile_campus_list():
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(f"{BACKEND_URL}/api/v1/campuses")
            resp.raise_for_status()
    except httpx.HTTPStatusError as exc:
        return Response(
            content=exc.response.content,
            status_code=exc.response.status_code,
            headers={"Content-Type": "application/json"},
        )
    except httpx.HTTPError:
        return Response(
            content=b'{"detail":"backend unavailable"}',
            status_code=502,
            headers={"Content-Type": "application/json"},
        )
    return [{"id": c["id"], "name": c["name"]} for c in resp.json()]


@app.get("/api/v1/mobile/campuses/{campus_id}/map", tags=["mobile"])
async def mobile_map_full(campus_id: str):
    async with httpx.AsyncClient(timeout=900.0) as client:
        resp = await client.get(f"{BACKEND_URL}/api/v1/campuses/{campus_id}/export")
    return Response(
        content=resp.content,
        status_code=resp.status_code,
        headers={"Content-Type": "application/json", "X-Gateway-Upstream": "backend"},
    )

# discards svg data for much smaller file sizes
@app.get("/api/v1/mobile/campuses/{campus_id}/map/light", tags=["mobile"])
async def mobile_map_light(campus_id: str):
    async with httpx.AsyncClient(timeout=900.0) as client:
        resp = await client.get(f"{BACKEND_URL}/api/v1/campuses/{campus_id}/export")
    if resp.status_code != 200:
        return Response(
            content=resp.content,
            status_code=resp.status_code,
            headers={"Content-Type": "application/json"},
        )
    data = resp.json()
    _strip_image_data(data)
    return data


@app.api_route("/api/v1/assistant", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
@app.api_route("/api/v1/assistant/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
async def proxy_assistant(request: Request, path: str):
    return await _proxy(request, ASSISTANT_URL, "assistant")


@app.api_route("/api/v1/room-summary", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
@app.api_route("/api/v1/room-summary/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
async def proxy_image_pipeline(request: Request, path: str = ""):
    return await _proxy(request, IMAGE_PIPELINE_URL, "image_pipeline")


@app.api_route(
    "/api/v1/ml-vision/{path:path}",
    methods=["GET", "POST", "PUT", "DELETE", "PATCH"],
    include_in_schema=False,
)
async def proxy_ml_vision(request: Request, path: str):
    upstream_path = f"/{path}" if path else "/"
    query = str(request.url.query)
    url = f"{ML_VISION_URL}{upstream_path}"
    if query:
        url = f"{url}?{query}"

    body = await request.body()
    headers = dict(request.headers)
    headers.pop("host", None)
    _apply_identity_headers(
        headers, _decode_identity(request.headers.get("authorization")),
    )

    try:
        async with httpx.AsyncClient(timeout=900.0) as client:
            resp = await client.request(
                method=request.method,
                url=url,
                headers=headers,
                content=body,
            )
    except httpx.HTTPError:
        return Response(
            content=b'{"detail":"ml_vision unavailable"}',
            status_code=502,
            headers={"Content-Type": "application/json"},
        )

    return Response(
        content=resp.content,
        status_code=resp.status_code,
        headers=_relay_headers(resp.headers, "ml_vision"),
    )


def _http_to_ws(url: str) -> str:
    if url.startswith("https://"):
        return "wss://" + url[len("https://"):]
    if url.startswith("http://"):
        return "ws://" + url[len("http://"):]
    return url


@app.websocket("/api/v1/ml-vision/ws/stream/{facility_id}")
async def proxy_ml_vision_stream(websocket: WebSocket, facility_id: str):
    """Bidirectional bridge between an iOS/Android client WebSocket and the
    ml_vision service. Auth is enforced here (the HTTP auth middleware does
    not run on WebSocket handshakes)."""
    if not API_SECRET or websocket.headers.get("x-api-key") != API_SECRET:
        await websocket.close(code=4401)
        return

    await websocket.accept()

    upstream_ws_base = _http_to_ws(ML_VISION_URL)
    upstream_url = f"{upstream_ws_base}/ws/stream/{facility_id}"

    try:
        async with websockets.connect(
            upstream_url,
            max_size=None,
            open_timeout=10,
            ping_interval=20,
            ping_timeout=20,
        ) as upstream:

            async def client_to_upstream() -> None:
                try:
                    while True:
                        msg = await websocket.receive()
                        if msg.get("type") == "websocket.disconnect":
                            return
                        data = msg.get("bytes")
                        text = msg.get("text")
                        if data is not None:
                            await upstream.send(data)
                        elif text is not None:
                            await upstream.send(text)
                except WebSocketDisconnect:
                    return

            async def upstream_to_client() -> None:
                try:
                    async for msg in upstream:
                        if isinstance(msg, (bytes, bytearray)):
                            await websocket.send_bytes(bytes(msg))
                        else:
                            await websocket.send_text(msg)
                except websockets.ConnectionClosed:
                    return

            tasks = [
                asyncio.create_task(client_to_upstream()),
                asyncio.create_task(upstream_to_client()),
            ]
            done, pending = await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
            for t in pending:
                t.cancel()
    except (OSError, websockets.InvalidURI, websockets.InvalidHandshake):
        # upstream unreachable or rejected handshake
        try:
            await websocket.close(code=1011)
        except Exception:
            pass
        return
    except Exception as exc:
        print(f"[ml_vision stream bridge] error: {exc}")
    finally:
        try:
            await websocket.close()
        except Exception:
            pass


@app.api_route("/api/{path:path}", methods=["GET", "POST", "PUT", "DELETE", "PATCH"], include_in_schema=False)
async def proxy_backend(request: Request, path: str):
    return await _proxy(request, BACKEND_URL, "backend")
